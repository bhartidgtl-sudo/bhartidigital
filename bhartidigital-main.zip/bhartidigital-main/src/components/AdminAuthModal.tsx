import React, { useState } from 'react';
import { X, Lock, ShieldCheck, KeyRound, CheckCircle2, AlertCircle } from 'lucide-react';
import { sounds } from '../utils/notifications';

interface AdminAuthModalProps {
  isOpen: boolean;
  isAdmin: boolean;
  currentPin: string;
  onClose: () => void;
  onUnlock: () => void;
  onLock: () => void;
  onChangePin: (newPin: string) => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  isAdmin,
  currentPin,
  onClose,
  onUnlock,
  onLock,
  onChangePin,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [error, setError] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinSavedMsg, setPinSavedMsg] = useState('');

  if (!isOpen) return null;

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.trim() === currentPin) {
      setError('');
      setPinInput('');
      sounds.playSuccess();
      onUnlock();
      onClose();
    } else {
      setError('Incorrect Admin PIN. Only the library admin can edit records.');
      sounds.playAlert();
    }
  };

  const handleChangePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinSavedMsg('');
    if (!/^\d{4,6}$/.test(newPin)) {
      setError('Admin PIN must be 4 to 6 digits.');
      return;
    }
    if (newPin !== confirmPin) {
      setError('PINs do not match.');
      return;
    }
    setError('');
    onChangePin(newPin);
    setNewPin('');
    setConfirmPin('');
    setPinSavedMsg('Admin PIN updated successfully.');
    sounds.playSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isAdmin
                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600'
                : 'bg-amber-50 dark:bg-amber-950 text-amber-600'
            }`}>
              {isAdmin ? <ShieldCheck className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAdmin ? 'Admin Controls Active' : 'Admin Access Required'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {isAdmin ? 'Editing & fee updates unlocked' : 'Only admin can edit student fees & details'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {!isAdmin ? (
            <form onSubmit={handleUnlockSubmit} className="space-y-4">
              <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-200">
                Student edits, fee changes, and approvals are restricted to the <strong>Admin</strong>. Enter your Admin PIN to unlock editing.
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Enter Admin PIN
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    inputMode="numeric"
                    autoFocus
                    required
                    value={pinInput}
                    onChange={e => {
                      setPinInput(e.target.value);
                      setError('');
                    }}
                    placeholder="••••"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                {currentPin === '1234' && (
                  <p className="text-[11px] text-slate-400 mt-1.5">
                    Default owner PIN: <strong className="font-mono text-slate-600 dark:text-slate-300">1234</strong> (you can change it after unlocking)
                  </p>
                )}
              </div>

              {error && (
                <div className="flex items-center gap-1.5 text-xs text-rose-600 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Unlock Admin Edit</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 flex items-center justify-between gap-2">
                <div className="text-xs text-emerald-900 dark:text-emerald-200">
                  <strong>Admin Mode Unlocked</strong>
                  <p className="text-[11px] opacity-80">Lock before handing device to students/staff.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onLock();
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1 shrink-0"
                >
                  <Lock className="w-3 h-3" />
                  <span>Lock Now</span>
                </button>
              </div>

              <form onSubmit={handleChangePinSubmit} className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Change Admin PIN
                </h3>
                <div className="grid grid-cols-2 gap-2.5">
                  <input
                    type="password"
                    inputMode="numeric"
                    value={newPin}
                    onChange={e => {
                      setNewPin(e.target.value);
                      setError('');
                    }}
                    placeholder="New PIN (4-6 digits)"
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                  />
                  <input
                    type="password"
                    inputMode="numeric"
                    value={confirmPin}
                    onChange={e => {
                      setConfirmPin(e.target.value);
                      setError('');
                    }}
                    placeholder="Confirm PIN"
                    className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                  />
                </div>

                {error && (
                  <p className="text-xs text-rose-600 font-medium">{error}</p>
                )}
                {pinSavedMsg && (
                  <p className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{pinSavedMsg}</span>
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-xs"
                >
                  Update Admin PIN
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
