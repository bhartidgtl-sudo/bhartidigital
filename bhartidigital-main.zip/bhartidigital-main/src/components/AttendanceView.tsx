import React, { useState, useMemo } from 'react';
import { 
  Clock, 
  Search, 
  LogOut, 
  Download, 
  QrCode, 
  History,
  Users,
  Calendar,
  IndianRupee,
  CheckCircle2,
  XCircle,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle,
  ClipboardCheck
} from 'lucide-react';
import { Student, AttendanceRecord, Invoice, LibrarySettings, ShiftType, formatStudentShifts } from '../types';
import { YearlyFeeMatrix } from './YearlyFeeMatrix';
import { DailyAttendanceSheet } from './DailyAttendanceSheet';
import { sounds } from '../utils/notifications';

interface AttendanceViewProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  invoices: Invoice[];
  settings: LibrarySettings;
  isAdmin: boolean;
  onRequireAdmin: () => void;
  onRecordPayment: (studentId: string, amount: number, method: 'UPI' | 'CASH' | 'CARD', targetYearMonth?: string) => Invoice;
  onCheckInToggle: (studentId: string, method: 'STAFF_MANUAL' | 'QR_SCAN') => { success: boolean; student?: Student; action?: 'IN' | 'OUT' };
  onMarkDailyAttendance: (
    studentId: string,
    dateStr: string,
    action: 'PRESENT' | 'ABSENT' | 'CHECK_OUT',
    inTime?: string,
    outTime?: string
  ) => void;
  onBulkMarkDailyAttendance: (
    studentIds: string[],
    dateStr: string,
    action: 'PRESENT' | 'ABSENT'
  ) => void;
  onOpenKiosk: () => void;
  onSelectStudent: (student: Student) => void;
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const SHORT_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  students,
  attendanceRecords,
  invoices,
  settings,
  isAdmin,
  onRequireAdmin,
  onRecordPayment,
  onCheckInToggle,
  onMarkDailyAttendance,
  onBulkMarkDailyAttendance,
  onOpenKiosk,
  onSelectStudent,
}) => {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthIdx = now.getMonth(); // 0-indexed (10 = Nov)
  const currentYearMonth = `${currentYear}-${String(currentMonthIdx + 1).padStart(2, '0')}`;

  const prevDate = new Date(currentYear, currentMonthIdx - 1, 1);
  const lastYearMonth = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2, '0')}`;
  const lastMonthName = `${MONTH_NAMES[prevDate.getMonth()]} ${prevDate.getFullYear()}`;
  const currentMonthName = `${MONTH_NAMES[currentMonthIdx]} ${currentYear}`;

  const [subTab, setSubTab] = useState<'DAILY_SHEET' | 'LIVE' | 'MONTHLY' | 'YEARLY_FEES' | 'HISTORY'>('DAILY_SHEET');
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [selectedMonthIdx, setSelectedMonthIdx] = useState<number>(currentMonthIdx);
  const [monthlyFilter, setMonthlyFilter] = useState<'ALL' | 'PRESENT' | 'ABSENT' | 'FEE_PAID' | 'FEE_UNPAID'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [shiftFilter, setShiftFilter] = useState<string>('ALL');
  const [collectTarget, setCollectTarget] = useState<{ student: Student; ym: string } | null>(null);
  const [collectAmount, setCollectAmount] = useState<number>(500);
  const [collectMethod, setCollectMethod] = useState<'UPI' | 'CASH' | 'CARD'>('UPI');

  const selectedYearMonth = `${selectedYear}-${String(selectedMonthIdx + 1).padStart(2, '0')}`;
  const selectedMonthLabel = `${MONTH_NAMES[selectedMonthIdx]} ${selectedYear}`;

  const activeStudents = students.filter(s => s.attendanceStatus === 'CHECKED_IN');

  // Helper to compute stats for any YYYY-MM string
  const getMonthSummary = (ym: string) => {
    const monthRecords = attendanceRecords.filter(r => r.checkInTime.startsWith(ym));
    const monthInvoices = invoices.filter(
      inv => inv.status === 'PAID' && (inv.periodStart ? inv.periodStart.startsWith(ym) : inv.paidDate.startsWith(ym))
    );

    const presentStudentIds = new Set<string>(monthRecords.map(r => r.studentId));
    const paidStudentIds = new Set<string>(monthInvoices.map(inv => inv.studentId));
    const totalFeeCollected = monthInvoices.reduce((acc, inv) => acc + inv.amount, 0);

    return {
      ym,
      presentCount: presentStudentIds.size,
      absentCount: Math.max(0, students.length - presentStudentIds.size),
      totalVisits: monthRecords.length,
      paidStudentsCount: paidStudentIds.size,
      unpaidStudentsCount: Math.max(0, students.length - paidStudentIds.size),
      totalFeeCollected,
      monthRecords,
      monthInvoices,
      presentStudentIds,
      paidStudentIds,
    };
  };

  const currentMonthStats = useMemo(
    () => getMonthSummary(currentYearMonth),
    [attendanceRecords, invoices, students.length, currentYearMonth]
  );

  const lastMonthStats = useMemo(
    () => getMonthSummary(lastYearMonth),
    [attendanceRecords, invoices, students.length, lastYearMonth]
  );

  const selectedMonthStats = useMemo(
    () => getMonthSummary(selectedYearMonth),
    [attendanceRecords, invoices, students.length, selectedYearMonth]
  );

  // All 12 months summary for the selected year
  const yearlyOverview = useMemo(() => {
    return SHORT_MONTHS.map((shortLabel, idx) => {
      const ym = `${selectedYear}-${String(idx + 1).padStart(2, '0')}`;
      const summary = getMonthSummary(ym);
      return {
        idx,
        shortLabel,
        fullName: MONTH_NAMES[idx],
        ...summary,
      };
    });
  }, [selectedYear, attendanceRecords, invoices, students.length]);

  // Per-student breakdown for the selected month
  const studentMonthlyRows = useMemo(() => {
    return students
      .filter(s => {
        const matchesSearch =
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.assignedDesk.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesShift =
          shiftFilter === 'ALL' ||
          s.shift === shiftFilter ||
          (s.shifts && s.shifts.includes(shiftFilter as ShiftType));

        if (!matchesSearch || !matchesShift) return false;

        const isPresent = selectedMonthStats.presentStudentIds.has(s.id);
        const isPaid = selectedMonthStats.paidStudentIds.has(s.id);

        if (monthlyFilter === 'PRESENT') return isPresent;
        if (monthlyFilter === 'ABSENT') return !isPresent;
        if (monthlyFilter === 'FEE_PAID') return isPaid;
        if (monthlyFilter === 'FEE_UNPAID') return !isPaid;
        return true;
      })
      .map(s => {
        const visits = selectedMonthStats.monthRecords.filter(r => r.studentId === s.id);
        const paidInvoices = selectedMonthStats.monthInvoices.filter(inv => inv.studentId === s.id);
        const totalMinutes = visits.reduce((acc, v) => acc + (v.durationMinutes || 180), 0);
        const totalPaidAmount = paidInvoices.reduce((acc, inv) => acc + inv.amount, 0);

        return {
          student: s,
          visitCount: visits.length,
          totalHours: Math.round((totalMinutes / 60) * 10) / 10,
          isPresent: visits.length > 0,
          isPaid: paidInvoices.length > 0,
          paidAmount: totalPaidAmount,
          latestInvoice: paidInvoices[0],
        };
      });
  }, [students, selectedMonthStats, searchQuery, shiftFilter, monthlyFilter]);

  // Live / Directory filter
  const filteredStudents = (subTab === 'LIVE' ? activeStudents : students).filter(s => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.assignedDesk.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.phone.includes(searchQuery);

    const matchesShift =
      shiftFilter === 'ALL' ||
      s.shift === shiftFilter ||
      (s.shifts && s.shifts.includes(shiftFilter as ShiftType));

    return matchesSearch && matchesShift;
  });

  // Export CSV (exports selected month report when on MONTHLY tab, otherwise attendance logs)
  const handleExportCsv = () => {
    if (subTab === 'MONTHLY') {
      const headers = ['Student ID', 'Name', 'Desk', 'Shift', 'Month', 'Attendance Status', 'Visits', 'Fee Paid (INR)', 'Payment Status', 'Payment Method', 'Paid Date'];
      const rows = studentMonthlyRows.map(row => [
        row.student.id,
        `"${row.student.name}"`,
        row.student.assignedDesk,
        `"${formatStudentShifts(row.student.shifts, row.student.shift)}"`,
        selectedMonthLabel,
        row.isPresent ? 'Present' : 'Absent',
        row.visitCount,
        row.paidAmount,
        row.isPaid ? 'Paid' : 'Unpaid',
        row.latestInvoice?.paymentMethod || '-',
        row.latestInvoice?.paidDate || '-',
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const link = document.createElement('a');
      link.setAttribute('href', encodeURI(csvContent));
      link.setAttribute('download', `bharti_monthly_attendance_fee_${selectedYearMonth}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return;
    }

    const headers = ['Record ID', 'Student ID', 'Student Name', 'Desk', 'Shift', 'Check-In Time', 'Check-Out Time', 'Duration (Mins)', 'Method'];
    const rows = attendanceRecords.map(r => [
      r.id,
      r.studentId,
      `"${r.studentName}"`,
      r.assignedDesk,
      r.shift,
      r.checkInTime,
      r.checkOutTime || 'Currently Inside',
      r.durationMinutes || '-',
      r.method,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `bharti_attendance_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const attendanceDelta = currentMonthStats.presentCount - lastMonthStats.presentCount;
  const feeDelta = currentMonthStats.totalFeeCollected - lastMonthStats.totalFeeCollected;

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      {/* Top Controls Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Attendance & Daily Register
          </h2>
          <p className="text-xs text-slate-500">
            Daily student attendance sheet, live check-ins, month-by-month register (Jan–Dec), and monthly fee collection
          </p>
        </div>

        <div className="flex items-center gap-2">
          {subTab !== 'DAILY_SHEET' && (
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-colors min-h-[40px]"
            >
              <Download className="w-4 h-4" />
              <span>{subTab === 'MONTHLY' ? `Export ${SHORT_MONTHS[selectedMonthIdx]} CSV` : 'Export CSV'}</span>
            </button>
          )}
          <button
            onClick={onOpenKiosk}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm transition-all min-h-[40px]"
          >
            <QrCode className="w-4 h-4" />
            <span>Self Kiosk</span>
          </button>
        </div>
      </div>

      {/* Segmented View Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl">
        <div className="flex flex-wrap items-center gap-1">
          <button
            onClick={() => setSubTab('DAILY_SHEET')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
              subTab === 'DAILY_SHEET'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <ClipboardCheck className="w-4 h-4 text-emerald-600" />
            <span>Daily Attendance Sheet</span>
          </button>
          <button
            onClick={() => setSubTab('MONTHLY')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
              subTab === 'MONTHLY'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>Monthly Report (Jan–Dec)</span>
          </button>
          <button
            onClick={() => setSubTab('YEARLY_FEES')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
              subTab === 'YEARLY_FEES'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <AlertCircle className="w-4 h-4 text-rose-600" />
            <span>Jan–Dec Unpaid Fees</span>
          </button>
          <button
            onClick={() => setSubTab('LIVE')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
              subTab === 'LIVE'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-500" />
            <span>Live Inside ({activeStudents.length})</span>
          </button>
          <button
            onClick={() => setSubTab('HISTORY')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
              subTab === 'HISTORY'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <History className="w-4 h-4 text-slate-500" />
            <span>Visit Logs ({attendanceRecords.length})</span>
          </button>
        </div>

        {/* Shift Filter */}
        <div className="flex items-center gap-2 px-2">
          <select
            value={shiftFilter}
            onChange={e => setShiftFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-none"
          >
            <option value="ALL">All Shifts</option>
            <option value="AFTERNOON">4 Hr (12 PM - 4 PM · ₹300)</option>
            <option value="MORNING">6 Hr Morning (6 AM - 12 PM · ₹400)</option>
            <option value="EVENING">6 Hr Evening (5 PM - 11 PM · ₹400)</option>
            <option value="DAY_9TO5">8 Hr Day (9 AM - 5 PM · ₹500)</option>
            <option value="NIGHT_OWL">8 Hr Night (9 PM - 5 AM · ₹500)</option>
            <option value="TWELVE_HOURS">12 Hr Shift (7 AM - 7 PM · ₹700)</option>
            <option value="FULL_DAY">Full Day (6 AM - 11 PM · ₹750)</option>
            <option value="TWENTY_FOUR_HOURS">24 Hr (9 AM - 9 AM · ₹800)</option>
          </select>
        </div>
      </div>

      {/* DAILY ATTENDANCE SHEET FOR STUDENTS */}
      {subTab === 'DAILY_SHEET' && (
        <DailyAttendanceSheet
          students={students}
          attendanceRecords={attendanceRecords}
          shiftFilter={shiftFilter}
          onShiftFilterChange={setShiftFilter}
          onSelectStudent={onSelectStudent}
          onMarkDailyAttendance={onMarkDailyAttendance}
          onBulkMarkDailyAttendance={onBulkMarkDailyAttendance}
        />
      )}

      {/* MONTHLY ATTENDANCE & FEE REPORT SYSTEM */}
      {subTab === 'MONTHLY' && (
        <div className="space-y-5">
          {/* Current Month vs Last Month Comparison Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Current Month Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-600 to-slate-900 text-white shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full bg-white/15 text-[11px] font-bold uppercase tracking-wider">
                  Current Month · {currentMonthName}
                </span>
                <button
                  onClick={() => {
                    setSelectedYear(currentYear);
                    setSelectedMonthIdx(currentMonthIdx);
                  }}
                  className="text-xs font-semibold text-indigo-200 hover:text-white underline"
                >
                  View Details
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3 pt-1">
                <div>
                  <span className="text-[11px] text-indigo-200 block">Students Present</span>
                  <div className="text-2xl font-extrabold font-mono">
                    {currentMonthStats.presentCount}
                    <span className="text-xs font-normal text-indigo-200">/{students.length}</span>
                  </div>
                  <span className="text-[11px] text-emerald-300 flex items-center gap-0.5 mt-0.5">
                    {attendanceDelta >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    <span>{attendanceDelta >= 0 ? `+${attendanceDelta}` : attendanceDelta} vs last mo</span>
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-indigo-200 block">Fee Paid Students</span>
                  <div className="text-2xl font-extrabold font-mono">
                    {currentMonthStats.paidStudentsCount}
                    <span className="text-xs font-normal text-indigo-200">/{students.length}</span>
                  </div>
                  <span className="text-[11px] text-amber-300 block mt-0.5">
                    {currentMonthStats.unpaidStudentsCount} unpaid
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-indigo-200 block">Total Fee Paid</span>
                  <div className="text-2xl font-extrabold font-mono text-emerald-300">
                    ₹{currentMonthStats.totalFeeCollected.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[11px] text-indigo-200 block mt-0.5">
                    {feeDelta >= 0 ? `+₹${feeDelta.toLocaleString('en-IN')}` : `-₹${Math.abs(feeDelta).toLocaleString('en-IN')}`} vs last mo
                  </span>
                </div>
              </div>
            </div>

            {/* Last Month Card */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-bold uppercase tracking-wider">
                  Last Month · {lastMonthName}
                </span>
                <button
                  onClick={() => {
                    setSelectedYear(prevDate.getFullYear());
                    setSelectedMonthIdx(prevDate.getMonth());
                  }}
                  className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  View Details
                </button>
              </div>
              <div className="grid grid-cols-3 gap-3 pt-1">
                <div>
                  <span className="text-[11px] text-slate-500 block">Students Present</span>
                  <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white">
                    {lastMonthStats.presentCount}
                    <span className="text-xs font-normal text-slate-400">/{students.length}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {lastMonthStats.totalVisits} total visits
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Fee Paid Students</span>
                  <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white">
                    {lastMonthStats.paidStudentsCount}
                    <span className="text-xs font-normal text-slate-400">/{students.length}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {Math.round((lastMonthStats.paidStudentsCount / Math.max(1, students.length)) * 100)}% settled
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Total Fee Paid</span>
                  <div className="text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400">
                    ₹{lastMonthStats.totalFeeCollected.toLocaleString('en-IN')}
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Verified receipts
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 12-Month Selector & Year-Round Chart */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Select Month (January – December {selectedYear})
                </h3>
                <p className="text-xs text-slate-500">
                  Tap any month (e.g. January, February, October, November) to view present students and total fee paid
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setSelectedYear(prevDate.getFullYear());
                    setSelectedMonthIdx(prevDate.getMonth());
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                    selectedYearMonth === lastYearMonth
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Last Month ({SHORT_MONTHS[prevDate.getMonth()]})
                </button>
                <button
                  onClick={() => {
                    setSelectedYear(currentYear);
                    setSelectedMonthIdx(currentMonthIdx);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                    selectedYearMonth === currentYearMonth
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  Current ({SHORT_MONTHS[currentMonthIdx]})
                </button>
                <select
                  value={selectedYear}
                  onChange={e => setSelectedYear(Number(e.target.value))}
                  className="px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold"
                >
                  <option value={2026}>2026</option>
                  <option value={2025}>2025</option>
                </select>
              </div>
            </div>

            {/* Month Pills Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2">
              {yearlyOverview.map(m => {
                const isSelected = m.idx === selectedMonthIdx;
                return (
                  <button
                    key={m.ym}
                    onClick={() => setSelectedMonthIdx(m.idx)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-700'
                    }`}
                  >
                    <span className="text-xs font-bold block">{m.shortLabel}</span>
                    <span className={`text-[10px] font-mono block mt-0.5 ${isSelected ? 'text-indigo-100' : 'text-slate-500'}`}>
                      {m.presentCount} pres
                    </span>
                    <span className={`text-[10px] font-mono block ${isSelected ? 'text-emerald-200' : 'text-emerald-600 dark:text-emerald-400'}`}>
                      {m.paidStudentsCount} paid
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected Month KPI Strip */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">Present in {selectedMonthLabel}</span>
                <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white mt-0.5">
                  {selectedMonthStats.presentCount}{' '}
                  <span className="text-xs font-normal text-slate-400">/ {students.length} students</span>
                </div>
                <span className="text-[11px] text-emerald-600 font-semibold">
                  {Math.round((selectedMonthStats.presentCount / Math.max(1, students.length)) * 100)}% attendance · {selectedMonthStats.totalVisits} visits
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block">Absent in {selectedMonthLabel}</span>
                <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white mt-0.5">
                  {selectedMonthStats.absentCount}{' '}
                  <span className="text-xs font-normal text-slate-400">students</span>
                </div>
                <span className="text-[11px] text-slate-400">
                  No check-ins recorded
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40">
                <span className="text-[11px] text-emerald-800 dark:text-emerald-300 block">Students Who Paid Fee</span>
                <div className="text-2xl font-extrabold font-mono text-emerald-700 dark:text-emerald-400 mt-0.5">
                  {selectedMonthStats.paidStudentsCount}{' '}
                  <span className="text-xs font-normal">students</span>
                </div>
                <span className="text-[11px] text-rose-600 font-semibold">
                  {selectedMonthStats.unpaidStudentsCount} unpaid / due
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/20 border border-indigo-200/60 dark:border-indigo-900/40">
                <span className="text-[11px] text-indigo-800 dark:text-indigo-300 block">Total Fee Paid ({SHORT_MONTHS[selectedMonthIdx]})</span>
                <div className="text-2xl font-extrabold font-mono text-indigo-700 dark:text-indigo-300 mt-0.5 flex items-center gap-0.5">
                  <span>₹{selectedMonthStats.totalFeeCollected.toLocaleString('en-IN')}</span>
                </div>
                <span className="text-[11px] text-indigo-600 dark:text-indigo-400">
                  {selectedMonthStats.monthInvoices.length} paid receipts
                </span>
              </div>
            </div>
          </div>

          {/* Search & Filter Row for Selected Month Register */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={`Search ${selectedMonthLabel} register by name, ID, or desk...`}
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {([
                { id: 'ALL', label: `All (${students.length})` },
                { id: 'PRESENT', label: `Present (${selectedMonthStats.presentCount})` },
                { id: 'ABSENT', label: `Absent (${selectedMonthStats.absentCount})` },
                { id: 'FEE_PAID', label: `Fee Paid (${selectedMonthStats.paidStudentsCount})` },
                { id: 'FEE_UNPAID', label: `Unpaid (${selectedMonthStats.unpaidStudentsCount})` },
              ] as const).map(chip => (
                <button
                  key={chip.id}
                  onClick={() => setMonthlyFilter(chip.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                    monthlyFilter === chip.id
                      ? 'bg-slate-900 text-white dark:bg-indigo-600'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {chip.label}
                </button>
              ))}
            </div>
          </div>

          {/* Per-Student Monthly Attendance & Fee Register */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {selectedMonthLabel} Attendance & Fee Register ({studentMonthlyRows.length} students)
              </span>
              <span className="font-mono text-slate-400">Tap student to view Digital Pass</span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {studentMonthlyRows.length === 0 ? (
                <div className="p-10 text-center text-xs text-slate-400">
                  No students match this filter for {selectedMonthLabel}.
                </div>
              ) : (
                studentMonthlyRows.map(({ student, visitCount, totalHours, isPresent, isPaid, paidAmount, latestInvoice }) => (
                  <div
                    key={student.id}
                    onClick={() => onSelectStudent(student)}
                    className="p-3.5 sm:px-5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold text-xs shrink-0 font-mono">
                        {student.assignedDesk}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate">{student.name}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                            {student.id}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 block truncate">
                          {formatStudentShifts(student.shifts, student.shift)} · Monthly Rate: ₹{student.monthlyFee}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 pl-12 sm:pl-0">
                      {/* Attendance Badge */}
                      <div className="text-left sm:text-right">
                        {isPresent ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Present ({visitCount} visits · {totalHours}h)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 text-xs font-medium">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Absent</span>
                          </span>
                        )}
                      </div>

                      {/* Fee Paid Badge */}
                      <div className="text-right min-w-[115px]">
                        {isPaid ? (
                          <div>
                            <span className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400 block">
                              ₹{paidAmount.toLocaleString('en-IN')} Paid
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 block">
                              {latestInvoice?.paymentMethod} · {latestInvoice?.paidDate}
                            </span>
                          </div>
                        ) : (
                          <div>
                            <span className="text-xs font-bold text-rose-600 dark:text-rose-400 block">
                              Fee Unpaid
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 block">
                              Due ₹{student.monthlyFee}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* JAN-DEC YEARLY UNPAID FEE MATRIX */}
      {subTab === 'YEARLY_FEES' && (
        <YearlyFeeMatrix
          students={students}
          invoices={invoices}
          settings={settings}
          isAdmin={isAdmin}
          onRequireAdmin={onRequireAdmin}
          onCollectMonthFee={(student, ym) => {
            setCollectTarget({ student, ym });
            setCollectAmount(student.monthlyFee);
            setCollectMethod('UPI');
          }}
        />
      )}

      {/* Search Input Bar for LIVE & HISTORY */}
      {(subTab === 'LIVE' || subTab === 'HISTORY') && (
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by student name, desk number (e.g. A-12), PIN, or ID..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white placeholder:text-slate-400"
          />
        </div>
      )}

      {/* LIVE Attendance List */}
      {subTab === 'LIVE' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Showing {filteredStudents.length} members seated
            </span>
            <span className="font-mono">Real-time occupancy synced</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredStudents.length === 0 ? (
              <div className="p-12 text-center text-slate-400 text-sm">
                No matching active students found.
              </div>
            ) : (
              filteredStudents.map(student => (
                <div
                  key={student.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <div
                    className="flex items-center gap-3.5 cursor-pointer min-w-0"
                    onClick={() => onSelectStudent(student)}
                  >
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 flex items-center justify-center font-bold text-sm shrink-0">
                      {student.assignedDesk}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {student.name}
                        </h4>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {student.id}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span>Shift: <strong>{formatStudentShifts(student.shifts, student.shift)}</strong></span>
                        <span>·</span>
                        <span>PIN: <strong className="font-mono">{student.pin}</strong></span>
                        {student.lockerNumber && (
                          <>
                            <span>·</span>
                            <span>Locker: {student.lockerNumber}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 pl-13 sm:pl-0">
                    <div className="text-left sm:text-right">
                      <div className="flex items-center sm:justify-end gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>Checked In</span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block">
                        Entered: {student.currentCheckInTime ? student.currentCheckInTime.split('T')[1].substring(0, 5) : '08:00'} (~{student.currentCheckInDurationMinutes || 120}m)
                      </span>
                    </div>

                    {/* Manual Check-out trigger */}
                    <button
                      onClick={() => onCheckInToggle(student.id, 'STAFF_MANUAL')}
                      className="px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900 hover:bg-rose-50 dark:hover:bg-rose-950 text-rose-600 dark:text-rose-400 font-semibold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap min-h-[36px]"
                      title="Check out student"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Check Out</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* HISTORY Attendance Log */}
      {subTab === 'HISTORY' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-500 flex items-center justify-between">
            <span>Historical Session Records</span>
            <span>{attendanceRecords.length} Total Visits Recorded</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {attendanceRecords.slice(0, 40).map(rec => (
              <div key={rec.id} className="p-4 flex items-center justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white truncate">{rec.studentName}</span>
                    <span className="font-mono text-slate-400 text-[10px]">({rec.studentId})</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 font-mono text-[10px]">
                      Desk {rec.assignedDesk}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {rec.checkInTime.replace('T', ' ')} → {rec.checkOutTime ? rec.checkOutTime.replace('T', ' ') : 'Present Now'}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="font-mono font-semibold text-slate-700 dark:text-slate-300 block">
                    {rec.durationMinutes ? `${Math.floor(rec.durationMinutes / 60)}h ${rec.durationMinutes % 60}m` : 'Active'}
                  </span>
                  <span className="text-[10px] text-slate-400 uppercase font-mono">
                    via {rec.method.replace('_', ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Month-Specific Fee Collection Modal from Jan-Dec Matrix */}
      {isAdmin && collectTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Collect Unpaid Month Fee
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                <strong>{collectTarget.student.name}</strong> ({collectTarget.student.id}) · Month:{' '}
                <strong className="font-mono text-indigo-600">{collectTarget.ym}</strong>
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Fee Amount (₹)
              </label>
              <input
                type="number"
                min={0}
                value={collectAmount}
                onChange={e => setCollectAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              {(['UPI', 'CASH', 'CARD'] as const).map(m => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setCollectMethod(m)}
                  className={`py-2 rounded-xl text-xs font-bold transition-colors ${
                    collectMethod === m
                      ? 'bg-slate-900 dark:bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCollectTarget(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onRecordPayment(collectTarget.student.id, collectAmount, collectMethod, collectTarget.ym);
                  sounds.playSuccess();
                  setCollectTarget(null);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Confirm ₹{collectAmount} Paid</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
