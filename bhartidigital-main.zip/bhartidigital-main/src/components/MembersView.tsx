import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  UserPlus, 
  QrCode, 
  CreditCard, 
  MessageSquare, 
  Phone, 
  Mail, 
  Sparkles,
  Download,
  Calendar,
  MoreVertical,
  CheckCircle2,
  Clock,
  Pencil,
  Lock
} from 'lucide-react';
import { Student, LibrarySettings, ShiftType, PaymentStatus, formatStudentShifts } from '../types';
import { generateWhatsAppReminderUrl } from '../utils/notifications';
import { hasCustomOrDefaultPhoto, resolveStudentAvatar } from '../utils/assets';

interface MembersViewProps {
  students: Student[];
  settings: LibrarySettings;
  isAdmin: boolean;
  onRequireAdmin: () => void;
  pendingCount: number;
  onOpenApprovals: () => void;
  onOpenSelfRegister: () => void;
  onOpenRegister: () => void;
  onSelectStudent: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onOpenPaymentModal: (student: Student) => void;
  onCheckInToggle: (studentId: string, method: 'STAFF_MANUAL') => void;
}

export const MembersView: React.FC<MembersViewProps> = ({
  students,
  settings,
  isAdmin,
  onRequireAdmin,
  pendingCount,
  onOpenApprovals,
  onOpenSelfRegister,
  onOpenRegister,
  onSelectStudent,
  onEditStudent,
  onOpenPaymentModal,
  onCheckInToggle,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [shiftFilter, setShiftFilter] = useState<string>('ALL');

  const filteredStudents = students.filter(s => {
    const matchesSearch = 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.phone.includes(searchQuery) ||
      s.assignedDesk.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.courseOrExam && s.courseOrExam.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = 
      statusFilter === 'ALL' ||
      (statusFilter === 'CHECKED_IN' && s.attendanceStatus === 'CHECKED_IN') ||
      s.paymentStatus === statusFilter;

    const matchesShift = 
      shiftFilter === 'ALL' || 
      s.shift === shiftFilter || 
      (s.shifts && s.shifts.includes(shiftFilter as ShiftType));

    return matchesSearch && matchesStatus && matchesShift;
  });

  const exportStudentsCsv = () => {
    const headers = ['ID', 'PIN', 'Name', 'Phone', 'Email', 'Desk', 'Locker', 'Shift', 'Plan', 'Monthly Fee', 'Payment Status', 'Due Date', 'Exam/Target'];
    const rows = students.map(s => [
      s.id,
      s.pin,
      `"${s.name}"`,
      s.phone,
      s.email,
      s.assignedDesk,
      s.lockerNumber || 'None',
      `"${formatStudentShifts(s.shifts, s.shift)}"`,
      s.plan,
      s.monthlyFee,
      s.paymentStatus,
      s.renewalDueDate,
      `"${s.courseOrExam || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `libredesk_members_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Library Member Directory
          </h2>
          <p className="text-xs text-slate-500">
            Managing <strong className="font-mono">{students.length}</strong> enrolled students across 3 wings
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportStudentsCsv}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-colors min-h-[40px]"
          >
            <Download className="w-4 h-4" />
            <span>Export Roster</span>
          </button>
          <button
            onClick={onOpenSelfRegister}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-xl transition-colors min-h-[40px]"
          >
            <UserPlus className="w-4 h-4" />
            <span>Self-Register Link</span>
          </button>
          {isAdmin ? (
            <button
              onClick={onOpenRegister}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-700 rounded-xl shadow-sm transition-all min-h-[40px]"
            >
              <span>+ Quick Add</span>
            </button>
          ) : (
            <button
              onClick={onRequireAdmin}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 rounded-xl transition-colors min-h-[40px]"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Unlock Admin Edit</span>
            </button>
          )}
        </div>
      </div>

      {!isAdmin && (
        <div className="px-4 py-2.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 flex items-center justify-between gap-2 text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>Read-only directory mode. Only the <strong>Admin</strong> can edit student fees, shifts, or details.</span>
          </div>
          <button
            onClick={onRequireAdmin}
            className="font-bold text-amber-800 dark:text-amber-300 underline shrink-0"
          >
            Admin Login
          </button>
        </div>
      )}

      {/* Filter Chips Strip */}
      <div className="flex flex-wrap items-center gap-2">
        {pendingCount > 0 && (
          <button
            onClick={onOpenApprovals}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
            <span>Pending Approvals ({pendingCount})</span>
          </button>
        )}
        <button
          onClick={() => setStatusFilter('ALL')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            statusFilter === 'ALL'
              ? 'bg-slate-900 text-white dark:bg-indigo-600'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          All Enrolled ({students.length})
        </button>
        <button
          onClick={() => setStatusFilter('CHECKED_IN')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            statusFilter === 'CHECKED_IN'
              ? 'bg-emerald-600 text-white'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>Seated Now ({students.filter(s => s.attendanceStatus === 'CHECKED_IN').length})</span>
        </button>
        <button
          onClick={() => setStatusFilter('OVERDUE')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            statusFilter === 'OVERDUE'
              ? 'bg-rose-600 text-white'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <span>Overdue ({students.filter(s => s.paymentStatus === 'OVERDUE').length})</span>
        </button>
        <button
          onClick={() => setStatusFilter('DUE_SOON')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            statusFilter === 'DUE_SOON'
              ? 'bg-amber-600 text-white'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          <span>Due in 3d ({students.filter(s => s.paymentStatus === 'DUE_SOON').length})</span>
        </button>
        <button
          onClick={() => setStatusFilter('PAID')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            statusFilter === 'PAID'
              ? 'bg-slate-900 text-white dark:bg-indigo-600'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          Paid Up ({students.filter(s => s.paymentStatus === 'PAID').length})
        </button>
      </div>

      {/* Search & Shift Filter Row */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search 100+ students by name, desk, PIN, exam (UPSC, NEET)..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
          />
        </div>

        <select
          value={shiftFilter}
          onChange={e => setShiftFilter(e.target.value)}
          className="px-3 py-2.5 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs font-medium focus:outline-none"
        >
          <option value="ALL">All Shift Times</option>
          <option value="AFTERNOON">4 Hr · 12 PM - 4 PM (₹300)</option>
          <option value="MORNING">6 Hr Morning · 6 AM - 12 PM (₹400)</option>
          <option value="EVENING">6 Hr Evening · 5 PM - 11 PM (₹400)</option>
          <option value="DAY_9TO5">8 Hr · 9 AM - 5 PM (₹500)</option>
          <option value="NIGHT_OWL">8 Hr Night · 9 PM - 5 AM (₹500)</option>
          <option value="TWELVE_HOURS">12 Hr · 7 AM - 7 PM (₹700)</option>
          <option value="FULL_DAY">Full Day · 6 AM - 11 PM (₹750)</option>
          <option value="TWENTY_FOUR_HOURS">24 Hr · 9 AM - 9 AM (₹800)</option>
        </select>
      </div>

      {/* Student List Cards */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            Showing {filteredStudents.length} of {students.length} members
          </span>
          <span className="font-mono">Tap any card to view Digital ID Pass</span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {filteredStudents.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No matching students found for "{searchQuery}".
            </div>
          ) : (
            filteredStudents.map(student => {
              const waUrl = generateWhatsAppReminderUrl(
                student.phone,
                student.name,
                student.renewalDueDate,
                student.monthlyFee,
                settings.name,
                student.assignedDesk
              );

              return (
                <div
                  key={student.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                >
                  {/* Left: Avatar & Identity */}
                  <div
                    className="flex items-center gap-3.5 cursor-pointer min-w-0"
                    onClick={() => onSelectStudent(student)}
                  >
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 flex items-center justify-center font-bold text-base border border-slate-200/60 dark:border-slate-700 shrink-0 relative">
                      {hasCustomOrDefaultPhoto(student.avatarUrl) ? (
                        <img
                          src={resolveStudentAvatar(student.avatarUrl)}
                          alt={student.name}
                          className="w-full h-full object-cover rounded-2xl"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        student.name.charAt(0)
                      )}
                      {student.attendanceStatus === 'CHECKED_IN' && (
                        <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" title="Present in library"></span>
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {student.name}
                        </h4>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {student.id}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span className="font-semibold text-indigo-600 dark:text-indigo-400 font-mono">
                          Desk: {student.assignedDesk}
                        </span>
                        <span>·</span>
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                          Shift: {formatStudentShifts(student.shifts, student.shift)}
                        </span>
                        <span>·</span>
                        <span className="truncate">{student.courseOrExam || 'Self Study'}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400">Admitted: {student.joinedDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Middle / Right: Fee Status & Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-2.5 pl-15 sm:pl-0">
                    <div className="text-left sm:text-right">
                      <div className="flex items-center sm:justify-end gap-1.5">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                          student.paymentStatus === 'PAID'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400'
                            : student.paymentStatus === 'OVERDUE'
                            ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400'
                            : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400'
                        }`}>
                          {student.paymentStatus === 'PAID' ? 'Fee Paid' : student.paymentStatus === 'OVERDUE' ? 'Overdue' : 'Due Soon'}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                        Due: {student.renewalDueDate} (₹{student.monthlyFee}/mo)
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Edit Fee & Student Details (Admin Only) */}
                      {isAdmin ? (
                        <button
                          onClick={() => onEditStudent(student)}
                          className="px-2.5 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-semibold text-xs flex items-center gap-1 transition-colors min-h-[36px]"
                          title="Edit Student Fee, Shift, Phone & Details"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                      ) : (
                        <button
                          onClick={onRequireAdmin}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 font-semibold text-xs flex items-center gap-1 transition-colors min-h-[36px]"
                          title="Admin PIN required to edit student details"
                        >
                          <Lock className="w-3 h-3" />
                          <span>Admin Only</span>
                        </button>
                      )}

                      {/* View ID Card Pass */}
                      <button
                        onClick={() => onSelectStudent(student)}
                        className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
                        title="View & Print Digital Student Pass"
                      >
                        <QrCode className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </button>

                      {/* WhatsApp Reminder if due */}
                      {isAdmin && (student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'DUE_SOON') && (
                        <a
                          href={waUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-600 transition-colors"
                          title="Send WhatsApp Payment Reminder"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </a>
                      )}

                      {/* Collect Fee Button (Admin Only) */}
                      {isAdmin && (
                        <button
                          onClick={() => onOpenPaymentModal(student)}
                          className="px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 text-white font-semibold text-xs flex items-center gap-1 transition-colors min-h-[36px]"
                          title="Record Payment & Generate Invoice"
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>Fee / Renew</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
