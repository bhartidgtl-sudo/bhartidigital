import React, { useState, useMemo } from 'react';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  LogOut,
  Download,
  CheckCheck,
  Edit3,
  Check,
  X,
} from 'lucide-react';
import {
  Student,
  AttendanceRecord,
  ShiftType,
  formatStudentShifts,
} from '../types';
import { sounds } from '../utils/notifications';

interface DailyAttendanceSheetProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  shiftFilter: string;
  onShiftFilterChange: (shift: string) => void;
  onSelectStudent: (student: Student) => void;
  onMarkDailyAttendance: (
    studentId: string,
    dateStr: string,
    action: 'PRESENT' | 'ABSENT' | 'CHECK_OUT',
    inTime?: string,
    outTime?: string
  ) => void;
  onBulkMarkDailyAttendance: (
    studentIds: string[],
    dateStr: string,
    action: 'PRESENT' | 'ABSENT'
  ) => void;
}

function getLocalDateString(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function shiftDateString(dateStr: string, deltaDays: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d + deltaDays);
  return getLocalDateString(dt);
}

function formatReadableDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function extractHHMM(isoStr?: string): string {
  if (!isoStr || !isoStr.includes('T')) return '';
  return isoStr.split('T')[1].substring(0, 5);
}

function formatTime12h(hhmm: string): string {
  if (!hhmm || !hhmm.includes(':')) return '--:--';
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  const m = Number(mStr);
  if (Number.isNaN(h) || Number.isNaN(m)) return hhmm;
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${String(hour12).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
}

function formatDuration(mins?: number): string {
  if (!mins || mins <= 0) return '—';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export const DailyAttendanceSheet: React.FC<DailyAttendanceSheetProps> = ({
  students,
  attendanceRecords,
  shiftFilter,
  onShiftFilterChange,
  onSelectStudent,
  onMarkDailyAttendance,
  onBulkMarkDailyAttendance,
}) => {
  const todayStr = getLocalDateString();
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PRESENT' | 'ABSENT' | 'INSIDE'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [editInTime, setEditInTime] = useState<string>('08:30');
  const [editOutTime, setEditOutTime] = useState<string>('');

  const isToday = selectedDate === todayStr;

  // Map studentId -> AttendanceRecord[] on selectedDate
  const recordsByStudent = useMemo(() => {
    const map = new Map<string, AttendanceRecord[]>();
    attendanceRecords.forEach(rec => {
      if (rec.checkInTime.startsWith(selectedDate)) {
        const list = map.get(rec.studentId) || [];
        list.push(rec);
        map.set(rec.studentId, list);
      }
    });
    return map;
  }, [attendanceRecords, selectedDate]);

  // Build daily sheet rows for every student
  const allRows = useMemo(() => {
    return students.map((student, index) => {
      const dayRecords = recordsByStudent.get(student.id) || [];
      // Pick latest / active record on that date
      const openRecord = dayRecords.find(r => !r.checkOutTime);
      const primaryRecord = openRecord || dayRecords[0];

      const isCheckedInNow = isToday && student.attendanceStatus === 'CHECKED_IN';
      const isPresent = dayRecords.length > 0 || isCheckedInNow;

      const inTimeHHMM =
        extractHHMM(primaryRecord?.checkInTime) ||
        (isCheckedInNow ? extractHHMM(student.currentCheckInTime) : '');
      const outTimeHHMM = primaryRecord?.checkOutTime ? extractHHMM(primaryRecord.checkOutTime) : '';

      const totalMinutes = dayRecords.reduce((sum, r) => {
        if (r.durationMinutes) return sum + r.durationMinutes;
        if (isToday && !r.checkOutTime && student.currentCheckInDurationMinutes) {
          return sum + student.currentCheckInDurationMinutes;
        }
        return sum;
      }, 0);

      return {
        serial: index + 1,
        student,
        dayRecords,
        primaryRecord,
        isPresent,
        isInside: Boolean(openRecord) || isCheckedInNow,
        inTimeHHMM,
        outTimeHHMM,
        totalMinutes,
      };
    });
  }, [students, recordsByStudent, isToday]);

  // Summary metrics (before status filter, respecting shift & search or overall roster)
  const summary = useMemo(() => {
    const presentCount = allRows.filter(r => r.isPresent).length;
    const absentCount = allRows.length - presentCount;
    const insideCount = allRows.filter(r => r.isInside).length;
    const rate = allRows.length > 0 ? Math.round((presentCount / allRows.length) * 100) : 0;
    return {
      total: allRows.length,
      presentCount,
      absentCount,
      insideCount,
      rate,
    };
  }, [allRows]);

  // Filtered rows for the table
  const filteredRows = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allRows.filter(row => {
      const { student, isPresent, isInside } = row;
      const matchesSearch =
        !q ||
        student.name.toLowerCase().includes(q) ||
        student.id.toLowerCase().includes(q) ||
        student.assignedDesk.toLowerCase().includes(q) ||
        student.phone.toLowerCase().includes(q);

      const matchesShift =
        shiftFilter === 'ALL' ||
        student.shift === shiftFilter ||
        (student.shifts && student.shifts.includes(shiftFilter as ShiftType));

      if (!matchesSearch || !matchesShift) return false;

      if (statusFilter === 'PRESENT') return isPresent;
      if (statusFilter === 'ABSENT') return !isPresent;
      if (statusFilter === 'INSIDE') return isInside;
      return true;
    });
  }, [allRows, searchQuery, shiftFilter, statusFilter]);

  const absentFilteredIds = useMemo(
    () => filteredRows.filter(r => !r.isPresent).map(r => r.student.id),
    [filteredRows]
  );

  const handleExportDailyCsv = () => {
    const headers = [
      'S.No',
      'Date',
      'Student ID',
      'Student Name',
      'Mobile',
      'Desk',
      'Shift',
      'Status',
      'In Time',
      'Out Time',
      'Study Duration',
    ];
    const rows = filteredRows.map((row, idx) => [
      idx + 1,
      selectedDate,
      row.student.id,
      `"${row.student.name}"`,
      row.student.phone,
      row.student.assignedDesk,
      `"${formatStudentShifts(row.student.shifts, row.student.shift)}"`,
      row.isInside ? 'Present (Inside)' : row.isPresent ? 'Present' : 'Absent',
      row.inTimeHHMM ? formatTime12h(row.inTimeHHMM) : '-',
      row.isInside ? 'Inside Now' : row.outTimeHHMM ? formatTime12h(row.outTimeHHMM) : '-',
      row.isPresent ? formatDuration(row.totalMinutes) : '0m',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csvContent));
    link.setAttribute('download', `bharti_daily_attendance_sheet_${selectedDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const startEditTimes = (row: (typeof allRows)[number]) => {
    setEditingRowId(row.student.id);
    setEditInTime(row.inTimeHHMM || '08:30');
    setEditOutTime(row.outTimeHHMM || (isToday && row.isInside ? '' : '14:30'));
  };

  const saveEditTimes = (studentId: string) => {
    onMarkDailyAttendance(
      studentId,
      selectedDate,
      'PRESENT',
      editInTime || '08:30',
      editOutTime || undefined
    );
    sounds.playSuccess();
    setEditingRowId(null);
  };

  return (
    <div className="space-y-4">
      {/* Sheet Title & Date Navigator Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Daily Student Attendance Sheet
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              <span>{formatReadableDate(selectedDate)}</span>
              <span aria-hidden="true"> · </span>
              <span>{isToday ? 'Live today register synced with kiosk check-ins' : 'Historical daily sheet'}</span>
            </p>
          </div>

          {/* Date Controls + Export */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800/70 overflow-hidden">
              <button
                type="button"
                onClick={() => setSelectedDate(prev => shiftDateString(prev, -1))}
                className="px-2.5 py-2 hover:bg-slate-200/70 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors min-h-[40px] flex items-center justify-center"
                title="Previous day"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="relative flex items-center px-2">
                <Calendar className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 mr-1.5 shrink-0" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={e => {
                    if (e.target.value) setSelectedDate(e.target.value);
                  }}
                  className="bg-transparent text-xs font-mono tabular-nums font-semibold text-slate-900 dark:text-white focus:outline-none py-1.5"
                />
              </div>
              <button
                type="button"
                onClick={() => setSelectedDate(prev => shiftDateString(prev, 1))}
                className="px-2.5 py-2 hover:bg-slate-200/70 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors min-h-[40px] flex items-center justify-center"
                title="Next day"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {!isToday && (
              <button
                type="button"
                onClick={() => setSelectedDate(todayStr)}
                className="px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs font-semibold hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors min-h-[40px] whitespace-nowrap"
              >
                Jump to Today
              </button>
            )}

            <button
              type="button"
              onClick={handleExportDailyCsv}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors min-h-[40px] whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Sheet CSV</span>
            </button>
          </div>
        </div>

        {/* Clean 4-Cell Summary Strip (Flat hairline dividers, tabular numbers) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 border border-slate-200 dark:border-slate-800 rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800 bg-slate-50/60 dark:bg-slate-800/30">
          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Total Roster</span>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
              {summary.total}
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Registered members
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Present on Sheet</span>
            <div className="text-2xl font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-0.5">
              {summary.presentCount}
              <span className="text-xs font-normal text-slate-500 dark:text-slate-400 ml-1.5">
                ({summary.rate}%)
              </span>
            </div>
            <span className="text-[11px] text-emerald-700 dark:text-emerald-400">
              Marked or checked in
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Absent</span>
            <div className="text-2xl font-bold font-mono tabular-nums text-rose-600 dark:text-rose-400 mt-0.5">
              {summary.absentCount}
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              No entry recorded
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Currently Inside</span>
            <div className="text-2xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400 mt-0.5">
              {summary.insideCount}
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              {isToday ? 'Active desks occupied' : 'Open sessions on date'}
            </span>
          </div>
        </div>
      </div>

      {/* Search, Filter Tabs, Shift Selector & Bulk Mark Action */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search student name, ID, desk (e.g. A-05), or mobile..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[42px]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Interactive Status Filter Buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            {(
              [
                { id: 'ALL', label: `All (${summary.total})` },
                { id: 'PRESENT', label: `Present (${summary.presentCount})` },
                { id: 'ABSENT', label: `Absent (${summary.absentCount})` },
                { id: 'INSIDE', label: `Inside (${summary.insideCount})` },
              ] as const
            ).map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === tab.id
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {absentFilteredIds.length > 0 && (
            <button
              type="button"
              onClick={() => {
                onBulkMarkDailyAttendance(absentFilteredIds, selectedDate, 'PRESENT');
                sounds.playSuccess();
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Mark {absentFilteredIds.length} Present</span>
            </button>
          )}
        </div>
      </div>

      {/* Daily Sheet Data Grid (Desktop Table + Mobile Stacked Rows) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span className="font-semibold text-slate-800 dark:text-slate-200">
            Showing {filteredRows.length} of {students.length} students · {formatReadableDate(selectedDate)}
          </span>
          <div className="flex items-center gap-3">
            {shiftFilter !== 'ALL' && (
              <button
                type="button"
                onClick={() => onShiftFilterChange('ALL')}
                className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
              >
                Clear shift filter
              </button>
            )}
            <span className="font-mono tabular-nums">Click student name for ID pass</span>
          </div>
        </div>

        {filteredRows.length === 0 ? (
          <div className="p-10 text-center space-y-2">
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              No students match your current search or filter
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Clear the search query or switch back to All students to view the full daily sheet.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('ALL');
                onShiftFilterChange('ALL');
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <>
            {/* Desktop / Tablet High-Density Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    <th className="py-2.5 px-4 w-12 font-mono">#</th>
                    <th className="py-2.5 px-4">Student</th>
                    <th className="py-2.5 px-4">Desk & Shift</th>
                    <th className="py-2.5 px-4">In Time</th>
                    <th className="py-2.5 px-4">Out Time</th>
                    <th className="py-2.5 px-4 text-right">Duration</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 px-4 text-right">Mark Attendance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {filteredRows.map((row, idx) => {
                    const { student, isPresent, isInside, inTimeHHMM, outTimeHHMM, totalMinutes } = row;
                    const isEditing = editingRowId === student.id;

                    return (
                      <tr
                        key={student.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        <td className="py-2.5 px-4 font-mono tabular-nums text-slate-400">
                          {String(idx + 1).padStart(2, '0')}
                        </td>

                        <td className="py-2.5 px-4">
                          <button
                            type="button"
                            onClick={() => onSelectStudent(student)}
                            className="text-left group focus:outline-none"
                          >
                            <div className="font-semibold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                              {student.name}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                              {student.id} · {student.phone}
                            </div>
                          </button>
                        </td>

                        <td className="py-2.5 px-4">
                          <div className="font-mono tabular-nums font-semibold text-slate-800 dark:text-slate-200">
                            Desk {student.assignedDesk}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {formatStudentShifts(student.shifts, student.shift)}
                          </div>
                        </td>

                        <td className="py-2.5 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {isEditing ? (
                            <input
                              type="time"
                              value={editInTime}
                              onChange={e => setEditInTime(e.target.value)}
                              className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          ) : inTimeHHMM ? (
                            formatTime12h(inTimeHHMM)
                          ) : (
                            <span className="text-slate-400">--:--</span>
                          )}
                        </td>

                        <td className="py-2.5 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {isEditing ? (
                            <input
                              type="time"
                              value={editOutTime}
                              onChange={e => setEditOutTime(e.target.value)}
                              className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                            />
                          ) : isInside ? (
                            <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Inside</span>
                          ) : outTimeHHMM ? (
                            formatTime12h(outTimeHHMM)
                          ) : (
                            <span className="text-slate-400">--:--</span>
                          )}
                        </td>

                        <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {isPresent ? formatDuration(totalMinutes) : '—'}
                        </td>

                        <td className="py-2.5 px-4">
                          {isInside ? (
                            <span className="inline-flex items-center gap-1.5 text-indigo-700 dark:text-indigo-300 font-semibold">
                              <Clock className="w-3.5 h-3.5 shrink-0" />
                              <span>Inside</span>
                            </span>
                          ) : isPresent ? (
                            <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                              <span>Present</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-rose-600 dark:text-rose-400 font-medium">
                              <XCircle className="w-3.5 h-3.5 shrink-0" />
                              <span>Absent</span>
                            </span>
                          )}
                        </td>

                        <td className="py-2.5 px-4 text-right">
                          {isEditing ? (
                            <div className="inline-flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => saveEditTimes(student.id)}
                                className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                                title="Save times"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingRowId(null)}
                                className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                                title="Cancel"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1.5">
                              {!isPresent && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    onMarkDailyAttendance(student.id, selectedDate, 'PRESENT');
                                    sounds.playSuccess();
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold transition-colors whitespace-nowrap"
                                >
                                  Mark Present
                                </button>
                              )}

                              {isInside && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    onMarkDailyAttendance(student.id, selectedDate, 'CHECK_OUT');
                                    sounds.playSuccess();
                                  }}
                                  className="px-2.5 py-1.5 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap"
                                >
                                  <LogOut className="w-3.5 h-3.5" />
                                  <span>Check Out</span>
                                </button>
                              )}

                              {isPresent && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => startEditTimes(row)}
                                    className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                                    title="Edit In / Out Time"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onMarkDailyAttendance(student.id, selectedDate, 'ABSENT');
                                    }}
                                    className="px-2.5 py-1.5 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 font-semibold transition-colors whitespace-nowrap"
                                  >
                                    Mark Absent
                                  </button>
                                </>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Ergonomic Card List */}
            <div className="md:hidden divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRows.map((row, idx) => {
                const { student, isPresent, isInside, inTimeHHMM, outTimeHHMM, totalMinutes } = row;
                const isEditing = editingRowId === student.id;

                return (
                  <div key={student.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => onSelectStudent(student)}
                        className="text-left min-w-0 flex-1"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono tabular-nums text-slate-400">
                            {String(idx + 1).padStart(2, '0')}.
                          </span>
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {student.name}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                          Desk {student.assignedDesk} · {student.id} · {formatStudentShifts(student.shifts, student.shift)}
                        </div>
                      </button>

                      <div className="shrink-0 text-xs font-semibold">
                        {isInside ? (
                          <span className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400">
                            <Clock className="w-3.5 h-3.5" />
                            <span>Inside</span>
                          </span>
                        ) : isPresent ? (
                          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Present</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Absent</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {isEditing ? (
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <label className="text-[11px] text-slate-500 block mb-1">In Time</label>
                          <input
                            type="time"
                            value={editInTime}
                            onChange={e => setEditInTime(e.target.value)}
                            className="w-full px-2.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white min-h-[42px]"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-slate-500 block mb-1">Out Time</label>
                          <input
                            type="time"
                            value={editOutTime}
                            onChange={e => setEditOutTime(e.target.value)}
                            className="w-full px-2.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white min-h-[42px]"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => saveEditTimes(student.id)}
                          className="py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold min-h-[44px]"
                        >
                          Save Times
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingRowId(null)}
                          className="py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold min-h-[44px]"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <div className="text-xs font-mono tabular-nums text-slate-600 dark:text-slate-400">
                          <span>In: {inTimeHHMM ? formatTime12h(inTimeHHMM) : '--:--'}</span>
                          <span className="mx-1.5">·</span>
                          <span>Out: {isInside ? 'Inside' : outTimeHHMM ? formatTime12h(outTimeHHMM) : '--:--'}</span>
                          {isPresent && (
                            <>
                              <span className="mx-1.5">·</span>
                              <span>{formatDuration(totalMinutes)}</span>
                            </>
                          )}
                        </div>

                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          {!isPresent ? (
                            <button
                              type="button"
                              onClick={() => {
                                onMarkDailyAttendance(student.id, selectedDate, 'PRESENT');
                                sounds.playSuccess();
                              }}
                              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold min-h-[44px]"
                            >
                              Mark Present
                            </button>
                          ) : (
                            <>
                              {isInside && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    onMarkDailyAttendance(student.id, selectedDate, 'CHECK_OUT');
                                    sounds.playSuccess();
                                  }}
                                  className="flex-1 px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-xs font-semibold min-h-[44px]"
                                >
                                  Check Out
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => startEditTimes(row)}
                                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold min-h-[44px]"
                              >
                                Edit Time
                              </button>
                              <button
                                type="button"
                                onClick={() => onMarkDailyAttendance(student.id, selectedDate, 'ABSENT')}
                                className="px-3 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs font-semibold min-h-[44px]"
                              >
                                Absent
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
