import React, { useState, useMemo } from 'react';
import {
  Search,
  Download,
  CheckCircle2,
  XCircle,
  AlertCircle,
  MessageSquare,
  IndianRupee,
  Lock,
  Calendar,
  Clock,
} from 'lucide-react';
import { Student, Invoice, LibrarySettings, formatStudentShifts } from '../types';

interface YearlyFeeMatrixProps {
  students: Student[];
  invoices: Invoice[];
  settings: LibrarySettings;
  isAdmin: boolean;
  onRequireAdmin: () => void;
  onCollectMonthFee: (student: Student, yearMonth: string) => void;
}

const MONTHS = [
  { num: '01', short: 'Jan', full: 'January' },
  { num: '02', short: 'Feb', full: 'February' },
  { num: '03', short: 'Mar', full: 'March' },
  { num: '04', short: 'Apr', full: 'April' },
  { num: '05', short: 'May', full: 'May' },
  { num: '06', short: 'Jun', full: 'June' },
  { num: '07', short: 'Jul', full: 'July' },
  { num: '08', short: 'Aug', full: 'August' },
  { num: '09', short: 'Sep', full: 'September' },
  { num: '10', short: 'Oct', full: 'October' },
  { num: '11', short: 'Nov', full: 'November' },
  { num: '12', short: 'Dec', full: 'December' },
];

export const YearlyFeeMatrix: React.FC<YearlyFeeMatrixProps> = ({
  students,
  invoices,
  settings,
  isAdmin,
  onRequireAdmin,
  onCollectMonthFee,
}) => {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthNum = now.getMonth() + 1; // 1..12

  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'ALL' | 'HAS_UNPAID' | 'CHRONIC_UNPAID' | 'ALL_PAID'>('HAS_UNPAID');
  const [includeDecemberUpcoming, setIncludeDecemberUpcoming] = useState(false);

  const invoiceMatchesMonth = (inv: Invoice, ym: string) => {
    if (inv.status !== 'PAID') return false;
    return inv.periodStart ? inv.periodStart.startsWith(ym) : inv.paidDate.startsWith(ym);
  };

  // Compute per-student Jan..Dec status
  const studentRows = useMemo(() => {
    return students.map(student => {
      const monthStatuses = MONTHS.map((m, idx) => {
        const monthNum = idx + 1;
        const ym = `${selectedYear}-${m.num}`;
        const matchingInvoices = invoices.filter(
          inv => inv.studentId === student.id && invoiceMatchesMonth(inv, ym)
        );
        const isPaid = matchingInvoices.length > 0;
        const paidAmount = matchingInvoices.reduce((sum, inv) => sum + inv.amount, 0);
        const isUpcoming =
          !includeDecemberUpcoming &&
          (selectedYear > currentYear || (selectedYear === currentYear && monthNum > currentMonthNum));

        return {
          ...m,
          ym,
          isPaid,
          isUpcoming,
          paidAmount,
          invoice: matchingInvoices[0],
        };
      });

      const dueMonths = monthStatuses.filter(ms => !ms.isPaid && !ms.isUpcoming);
      const paidMonths = monthStatuses.filter(ms => ms.isPaid);
      const totalPaidForYear = paidMonths.reduce((acc, ms) => acc + ms.paidAmount, 0);
      const totalUnpaidEstimate = dueMonths.length * student.monthlyFee;

      return {
        student,
        monthStatuses,
        dueMonths,
        paidMonths,
        totalPaidForYear,
        totalUnpaidEstimate,
      };
    });
  }, [students, invoices, selectedYear, currentYear, currentMonthNum, includeDecemberUpcoming]);

  const summary = useMemo(() => {
    const withUnpaid = studentRows.filter(r => r.dueMonths.length > 0);
    const chronicUnpaid = studentRows.filter(r => r.dueMonths.length >= 3);
    const allPaid = studentRows.filter(r => r.dueMonths.length === 0);
    const totalPendingAmount = withUnpaid.reduce((acc, r) => acc + r.totalUnpaidEstimate, 0);
    const totalCollectedYear = studentRows.reduce((acc, r) => acc + r.totalPaidForYear, 0);

    return {
      withUnpaidCount: withUnpaid.length,
      chronicUnpaidCount: chronicUnpaid.length,
      allPaidCount: allPaid.length,
      totalPendingAmount,
      totalCollectedYear,
    };
  }, [studentRows]);

  const filteredRows = useMemo(() => {
    return studentRows
      .filter(r => {
        const q = searchQuery.toLowerCase();
        const matchesSearch =
          r.student.name.toLowerCase().includes(q) ||
          r.student.id.toLowerCase().includes(q) ||
          r.student.assignedDesk.toLowerCase().includes(q) ||
          r.student.phone.includes(searchQuery);

        if (!matchesSearch) return false;
        if (filterMode === 'HAS_UNPAID') return r.dueMonths.length > 0;
        if (filterMode === 'CHRONIC_UNPAID') return r.dueMonths.length >= 3;
        if (filterMode === 'ALL_PAID') return r.dueMonths.length === 0;
        return true;
      })
      .sort((a, b) => b.dueMonths.length - a.dueMonths.length);
  }, [studentRows, searchQuery, filterMode]);

  const handleExportMatrixCsv = () => {
    const headers = [
      'Student ID',
      'Name',
      'Phone',
      'Desk',
      'Monthly Fee (INR)',
      ...MONTHS.map(m => `${m.short} ${selectedYear}`),
      'Unpaid Months Count',
      'Unpaid Month Names',
      'Estimated Pending (INR)',
      'Total Paid (INR)',
    ];

    const rows = filteredRows.map(r => [
      r.student.id,
      `"${r.student.name}"`,
      r.student.phone,
      r.student.assignedDesk,
      r.student.monthlyFee,
      ...r.monthStatuses.map(ms => (ms.isPaid ? `Paid (${ms.paidAmount})` : ms.isUpcoming ? 'Upcoming' : 'UNPAID')),
      r.dueMonths.length,
      `"${r.dueMonths.map(d => d.short).join(', ') || 'None'}"`,
      r.totalUnpaidEstimate,
      r.totalPaidForYear,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csvContent));
    link.setAttribute('download', `bharti_jan_dec_fee_tracker_${selectedYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* Header Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>January – December Student Fee Tracker ({selectedYear})</span>
          </h3>
          <p className="text-xs text-slate-500">
            Spot every student who missed any monthly fee from January to December. Green = Paid, Red = Unpaid.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={includeDecemberUpcoming}
              onChange={e => setIncludeDecemberUpcoming(e.target.checked)}
              className="w-3.5 h-3.5 text-indigo-600 rounded"
            />
            <span>Include Dec</span>
          </label>
          <select
            value={selectedYear}
            onChange={e => setSelectedYear(Number(e.target.value))}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
          >
            <option value={2026}>2026</option>
            <option value={2025}>2025</option>
          </select>
          <button
            onClick={handleExportMatrixCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 text-xs font-semibold text-slate-700 dark:text-slate-200"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Jan–Dec CSV</span>
          </button>
        </div>
      </div>

      {/* Yearly KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50">
          <span className="text-[11px] font-semibold text-rose-800 dark:text-rose-300 block">
            Students With Unpaid Months
          </span>
          <div className="text-2xl font-extrabold font-mono text-rose-700 dark:text-rose-400 mt-0.5">
            {summary.withUnpaidCount} <span className="text-xs font-normal">/ {students.length}</span>
          </div>
          <span className="text-[11px] text-rose-600 font-medium">
            {summary.chronicUnpaidCount} students missed 3+ months
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">
            Total Unpaid Dues ({selectedYear})
          </span>
          <div className="text-2xl font-extrabold font-mono text-rose-600 dark:text-rose-400 mt-0.5">
            ₹{summary.totalPendingAmount.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400">
            Across unpaid months
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">
            100% Paid All Months
          </span>
          <div className="text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
            {summary.allPaidCount} <span className="text-xs font-normal text-slate-400">students</span>
          </div>
          <span className="text-[11px] text-emerald-600 font-medium">
            Zero pending dues
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">
            Total Collected ({selectedYear})
          </span>
          <div className="text-2xl font-extrabold font-mono text-slate-900 dark:text-white mt-0.5">
            ₹{summary.totalCollectedYear.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400">
            Jan–Dec verified fees
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search student by name, ID, desk, or phone..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {([
            { id: 'HAS_UNPAID', label: `Unpaid Any Month (${summary.withUnpaidCount})` },
            { id: 'CHRONIC_UNPAID', label: `3+ Months Due (${summary.chronicUnpaidCount})` },
            { id: 'ALL_PAID', label: `All Paid (${summary.allPaidCount})` },
            { id: 'ALL', label: `All (${students.length})` },
          ] as const).map(chip => (
            <button
              key={chip.id}
              onClick={() => setFilterMode(chip.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                filterMode === chip.id
                  ? chip.id === 'HAS_UNPAID' || chip.id === 'CHRONIC_UNPAID'
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-900 text-white dark:bg-indigo-600'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Student Jan-Dec Matrix Cards */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="font-bold text-slate-800 dark:text-slate-200">
            Showing {filteredRows.length} students (sorted by most unpaid months)
          </span>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1 text-emerald-600 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" /> Paid
            </span>
            <span className="flex items-center gap-1 text-rose-600 font-semibold">
              <XCircle className="w-3.5 h-3.5" /> Unpaid (Tap to collect as Admin)
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <Clock className="w-3.5 h-3.5" /> Upcoming
            </span>
          </div>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {filteredRows.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-400">
              No students match this filter in {selectedYear}.
            </div>
          ) : (
            filteredRows.map(({ student, monthStatuses, dueMonths, totalUnpaidEstimate }) => {
              const unpaidLabel = dueMonths.map(d => d.short).join(', ');
              const waText = `Namaste ${student.name}, this is a fee reminder from ${settings.name}. Your monthly desk fee (₹${student.monthlyFee}/mo) is pending for ${dueMonths.length} month(s): ${unpaidLabel}. Total pending: ₹${totalUnpaidEstimate.toLocaleString('en-IN')}. Please settle at the counter or via UPI.`;
              const waUrl = `https://wa.me/${student.phone.replace(/\D/g, '')}?text=${encodeURIComponent(waText)}`;

              return (
                <div key={student.id} className="p-4 space-y-3 hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors">
                  {/* Top row: Student identity & summary */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {student.name}
                        </h4>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {student.id}
                        </span>
                        <span className="text-[10px] font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                          Desk {student.assignedDesk}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {formatStudentShifts(student.shifts, student.shift)} · Rate: <strong className="font-mono">₹{student.monthlyFee}/mo</strong>
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {dueMonths.length > 0 ? (
                        <span className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-bold">
                          {dueMonths.length} Month{dueMonths.length > 1 ? 's' : ''} Unpaid · ₹{totalUnpaidEstimate.toLocaleString('en-IN')} Due
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
                          All Months Paid ✓
                        </span>
                      )}

                      {dueMonths.length > 0 && (
                        <a
                          href={waUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-semibold flex items-center gap-1"
                          title="Send WhatsApp reminder listing unpaid months"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Remind</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* 12-Month Jan to Dec Grid */}
                  <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5">
                    {monthStatuses.map(ms => {
                      if (ms.isUpcoming) {
                        return (
                          <div
                            key={ms.ym}
                            className="py-1.5 px-1 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200/50 dark:border-slate-800 text-center opacity-60"
                            title={`${ms.full} ${selectedYear}: Upcoming`}
                          >
                            <span className="text-[10px] font-bold text-slate-400 block">{ms.short}</span>
                            <span className="text-[9px] text-slate-400 block">—</span>
                          </div>
                        );
                      }

                      if (ms.isPaid) {
                        return (
                          <div
                            key={ms.ym}
                            className="py-1.5 px-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900/60 text-center"
                            title={`${ms.full} ${selectedYear}: Paid ₹${ms.paidAmount} (${ms.invoice?.paymentMethod || 'PAID'} on ${ms.invoice?.paidDate})`}
                          >
                            <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 block">{ms.short}</span>
                            <span className="text-[9px] font-mono font-semibold text-emerald-600 dark:text-emerald-400 block">
                              ✓ ₹{ms.paidAmount}
                            </span>
                          </div>
                        );
                      }

                      return (
                        <button
                          key={ms.ym}
                          type="button"
                          onClick={() => {
                            if (!isAdmin) {
                              onRequireAdmin();
                              return;
                            }
                            onCollectMonthFee(student, ms.ym);
                          }}
                          className="py-1.5 px-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900/60 text-center transition-colors group"
                          title={
                            isAdmin
                              ? `${ms.full} ${selectedYear} UNPAID — Click to collect ₹${student.monthlyFee}`
                              : `${ms.full} ${selectedYear} UNPAID — Admin login required to collect`
                          }
                        >
                          <span className="text-[10px] font-bold text-rose-800 dark:text-rose-300 block">{ms.short}</span>
                          <span className="text-[9px] font-bold text-rose-600 dark:text-rose-400 block">
                            ✗ Due
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
