import React, { useState, useEffect } from 'react';
import { X, Save, IndianRupee, Armchair, CreditCard, RotateCcw, Camera } from 'lucide-react';
import {
  Student,
  ShiftType,
  PaymentStatus,
  LibrarySettings,
  SHIFT_LIST,
  formatStudentShifts,
  calculateShiftFee,
  getTotalShiftHours,
} from '../types';
import { sounds } from '../utils/notifications';
import { CameraCaptureModal } from './CameraCaptureModal';
import { resolveStudentAvatar } from '../utils/assets';

interface EditStudentModalProps {
  student: Student | null;
  settings: LibrarySettings;
  onClose: () => void;
  onSave: (updatedStudent: Student) => void;
  onOpenPayment?: (student: Student) => void;
}

export const EditStudentModal: React.FC<EditStudentModalProps> = ({
  student,
  settings,
  onClose,
  onSave,
  onOpenPayment,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [courseOrExam, setCourseOrExam] = useState('');
  const [selectedShifts, setSelectedShifts] = useState<ShiftType[]>(['DAY_9TO5']);
  const [assignedDesk, setAssignedDesk] = useState('');
  const [hasLocker, setHasLocker] = useState(false);
  const [lockerNumber, setLockerNumber] = useState('');
  const [monthlyFee, setMonthlyFee] = useState<number>(500);
  const [isFeeOverridden, setIsFeeOverridden] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('PAID');
  const [joinedDate, setJoinedDate] = useState('');
  const [lastPaymentDate, setLastPaymentDate] = useState('');
  const [cardValidFrom, setCardValidFrom] = useState('');
  const [renewalDueDate, setRenewalDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  useEffect(() => {
    if (student) {
      setName(student.name);
      setPhone(student.phone);
      setEmail(student.email);
      setCourseOrExam(student.courseOrExam || '');
      const initialShifts =
        student.shifts && student.shifts.length > 0 ? student.shifts : [student.shift];
      setSelectedShifts(initialShifts);
      setAssignedDesk(student.assignedDesk);
      setHasLocker(student.hasLocker);
      setLockerNumber(student.lockerNumber || '');
      setMonthlyFee(student.monthlyFee);
      const standardFee = calculateShiftFee(initialShifts, settings.monthlyFees);
      setIsFeeOverridden(student.monthlyFee !== standardFee);
      setPaymentStatus(student.paymentStatus);
      setJoinedDate(student.joinedDate);
      setLastPaymentDate(student.lastPaymentDate || '');
      setCardValidFrom(student.cardValidFrom || student.lastPaymentDate || student.joinedDate);
      setRenewalDueDate(student.renewalDueDate);
      setNotes(student.notes || '');
      setAvatarUrl(student.avatarUrl);
    }
  }, [student, settings.monthlyFees]);

  if (!student) return null;

  const recommendedFee = calculateShiftFee(selectedShifts, settings.monthlyFees);
  const totalHours = getTotalShiftHours(selectedShifts);

  const handleToggleShift = (shiftId: ShiftType) => {
    let nextShifts: ShiftType[];
    if (selectedShifts.includes(shiftId)) {
      if (selectedShifts.length <= 1) return;
      nextShifts = selectedShifts.filter(s => s !== shiftId);
    } else if (shiftId === 'TWENTY_FOUR_HOURS') {
      nextShifts = ['TWENTY_FOUR_HOURS'];
    } else {
      const without24 = selectedShifts.filter(s => s !== 'TWENTY_FOUR_HOURS');
      nextShifts = [...without24, shiftId];
    }

    setSelectedShifts(nextShifts);
    if (!isFeeOverridden) {
      setMonthlyFee(calculateShiftFee(nextShifts, settings.monthlyFees));
    }
  };

  const handleResetFee = () => {
    setIsFeeOverridden(false);
    setMonthlyFee(recommendedFee);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    const updated: Student = {
      ...student,
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      avatarUrl: avatarUrl || student.avatarUrl,
      courseOrExam: courseOrExam.trim() || 'Study Hall Member',
      shift: selectedShifts[0],
      shifts: selectedShifts,
      assignedDesk: assignedDesk.trim() || 'General / Flex',
      hasLocker,
      lockerNumber: hasLocker
        ? lockerNumber.trim() || `L-${Math.floor(100 + Math.random() * 899)}`
        : undefined,
      monthlyFee: Math.max(0, Number(monthlyFee) || 0),
      paymentStatus,
      joinedDate: joinedDate || student.joinedDate,
      lastPaymentDate: lastPaymentDate || undefined,
      cardValidFrom: cardValidFrom || lastPaymentDate || joinedDate || student.joinedDate,
      renewalDueDate,
      notes: notes.trim() || undefined,
    };

    onSave(updated);
    sounds.playSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Edit Student Fee & Details
            </h2>
            <p className="text-xs text-slate-500 font-mono">
              {student.id} · PIN: {student.pin}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Student Photo Capture Bar */}
          <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 shrink-0">
                <img
                  src={resolveStudentAvatar(avatarUrl)}
                  alt={name || 'Student'}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Student ID Photo
                </span>
                <span className="text-[11px] text-slate-500">
                  {avatarUrl.startsWith('data:image/') ? 'Custom camera photo saved' : 'Default library photo'}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsCameraOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Capture Photo</span>
            </button>
          </div>

          {/* Basic Identity */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Student Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Mobile Number *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Exam / Course Target
              </label>
              <input
                type="text"
                value={courseOrExam}
                onChange={e => setCourseOrExam(e.target.value)}
                placeholder="e.g. UPSC, SSC CGL, NEET, B.Tech"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Shift Timing Multi-Select */}
          <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Study Shift(s) · {totalHours}h/day
              </label>
              <span className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                Auto Tariff: ₹{recommendedFee}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {SHIFT_LIST.map(shiftDef => {
                const isSelected = selectedShifts.includes(shiftDef.id);
                return (
                  <button
                    type="button"
                    key={shiftDef.id}
                    onClick={() => handleToggleShift(shiftDef.id)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <span
                      className={`w-3 h-3 rounded flex items-center justify-center text-[9px] ${
                        isSelected
                          ? 'bg-white text-indigo-700 font-bold'
                          : 'border border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {isSelected ? '✓' : ''}
                    </span>
                    <span>{shiftDef.shortLabel}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-500 font-mono">
              Selected: {formatStudentShifts(selectedShifts)}
            </p>
          </div>

          {/* Desk & Locker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Assigned Desk / Seat
              </label>
              <div className="relative">
                <Armchair className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={assignedDesk}
                  onChange={e => setAssignedDesk(e.target.value)}
                  placeholder="e.g. A-12"
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Locker Allocation
              </label>
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 shrink-0">
                  <input
                    type="checkbox"
                    checked={hasLocker}
                    onChange={e => setHasLocker(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded"
                  />
                  <span>Locker</span>
                </label>
                {hasLocker && (
                  <input
                    type="text"
                    value={lockerNumber}
                    onChange={e => setLockerNumber(e.target.value)}
                    placeholder="L-101"
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Fee & Payment Status */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Monthly Fee (₹)
                  </label>
                  {monthlyFee !== recommendedFee && (
                    <button
                      type="button"
                      onClick={handleResetFee}
                      className="text-[10px] font-semibold text-indigo-600 hover:underline flex items-center gap-0.5"
                      title="Reset to shift rate"
                    >
                      <RotateCcw className="w-2.5 h-2.5" />
                      <span>₹{recommendedFee}</span>
                    </button>
                  )}
                </div>
                <div className="relative">
                  <IndianRupee className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min={0}
                    required
                    value={monthlyFee}
                    onChange={e => {
                      setIsFeeOverridden(true);
                      setMonthlyFee(Number(e.target.value));
                    }}
                    className="w-full pl-8 pr-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Payment Status
                </label>
                <select
                  value={paymentStatus}
                  onChange={e => setPaymentStatus(e.target.value as PaymentStatus)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="PAID">Paid</option>
                  <option value="DUE_SOON">Due Soon</option>
                  <option value="OVERDUE">Overdue</option>
                  <option value="EXPIRED">Expired</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Payment Date
                </label>
                <input
                  type="date"
                  value={lastPaymentDate}
                  onChange={e => setLastPaymentDate(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Admission Date & Card Validation From Date -> To Date */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Admission Date
                </label>
                <input
                  type="date"
                  value={joinedDate}
                  onChange={e => setJoinedDate(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Card Valid From
                </label>
                <input
                  type="date"
                  value={cardValidFrom}
                  onChange={e => setCardValidFrom(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Card Valid To (Due Date)
                </label>
                <input
                  type="date"
                  value={renewalDueDate}
                  onChange={e => setRenewalDueDate(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {onOpenPayment && (
              <div className="pt-1 flex items-center justify-between text-xs border-t border-indigo-100/80 dark:border-indigo-900/40">
                <span className="text-slate-500">Need to log a fee payment receipt now?</span>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenPayment({
                      ...student,
                      monthlyFee: Math.max(0, Number(monthlyFee) || 0),
                      assignedDesk: assignedDesk.trim() || student.assignedDesk,
                    });
                  }}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1"
                >
                  <CreditCard className="w-3 h-3" />
                  <span>Collect Fee</span>
                </button>
              </div>
            )}
          </div>

          {/* Additional Notes */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Additional Details / Notes (Guardian, Address, ID Ref, Concession)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Father: Ramesh Kumar · Aadhaar verified · Paid ₹500 via PhonePe"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>Save Student Details</span>
            </button>
          </div>
        </form>
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        studentName={name}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => setAvatarUrl(dataUrl)}
      />
    </div>
  );
};
