import React, { useState } from 'react';
import { X, UserPlus, Sparkles, Check, Armchair, Clock, IndianRupee, Camera } from 'lucide-react';
import { ShiftType, PlanType, Student, LibrarySettings, SHIFT_LIST, formatStudentShifts, calculateShiftFee, getTotalShiftHours } from '../types';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/notifications';
import { CameraCaptureModal } from './CameraCaptureModal';
import { defaultStudentAvatar } from '../utils/assets';

interface RegisterMemberModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegister: (newStudent: Omit<Student, 'id' | 'pin'>) => Student;
  onBatchSimulate: (count: number) => void;
  settings: LibrarySettings;
  availableDesksCount: number;
}

export const RegisterMemberModal: React.FC<RegisterMemberModalProps> = ({
  isOpen,
  onClose,
  onRegister,
  onBatchSimulate,
  settings,
  availableDesksCount,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [selectedShifts, setSelectedShifts] = useState<ShiftType[]>(['DAY_9TO5']);
  const [plan, setPlan] = useState<PlanType>('MONTHLY_FULL_DAY');
  const [assignedDesk, setAssignedDesk] = useState('A-15');
  const [hasLocker, setHasLocker] = useState(false);
  const [courseOrExam, setCourseOrExam] = useState('Civil Services / UPSC');
  const [customFee, setCustomFee] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [initialPaymentCollected, setInitialPaymentCollected] = useState(true);
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'CASH' | 'CARD'>('UPI');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [validFromDate, setValidFromDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [validToDate, setValidToDate] = useState(() => new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);

  if (!isOpen) return null;

  const handleToggleShift = (shiftId: ShiftType) => {
    if (selectedShifts.includes(shiftId)) {
      if (selectedShifts.length > 1) {
        setSelectedShifts(selectedShifts.filter(s => s !== shiftId));
      }
    } else {
      if (shiftId === 'TWENTY_FOUR_HOURS') {
        setSelectedShifts(['TWENTY_FOUR_HOURS']);
      } else {
        const without24 = selectedShifts.filter(s => s !== 'TWENTY_FOUR_HOURS');
        setSelectedShifts([...without24, shiftId]);
      }
    }
  };

  const recommendedShiftFee = calculateShiftFee(selectedShifts, settings.monthlyFees, plan, hasLocker);
  const computedMonthlyFee = customFee !== null ? customFee : recommendedShiftFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || selectedShifts.length === 0) return;

    const monthlyFee = computedMonthlyFee;
    const today = new Date().toISOString().split('T')[0];
    const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const created = onRegister({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, '.')}@bhartilibrary.in`,
      avatarUrl: capturedPhoto || defaultStudentAvatar,
      assignedDesk: assignedDesk || 'General / Flex',
      hasLocker,
      lockerNumber: hasLocker ? `L-${Math.floor(100 + Math.random() * 899)}` : undefined,
      shift: selectedShifts[0],
      shifts: selectedShifts,
      plan,
      monthlyFee,
      paymentStatus: initialPaymentCollected ? 'PAID' : 'DUE_SOON',
      joinedDate: today,
      cardValidFrom: validFromDate || today,
      renewalDueDate: validToDate || dueDate,
      lastPaymentDate: initialPaymentCollected ? (paymentDate || today) : undefined,
      attendanceStatus: 'CHECKED_OUT',
      totalVisitsThisMonth: 0,
      avgHoursPerVisit: 0,
      courseOrExam,
      notes: notes.trim() || undefined,
    });

    sounds.playSuccess();
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">New Student Registration</h2>
              <p className="text-xs text-slate-500">{availableDesksCount} seats currently available</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* High Volume Batch Simulation Banner */}
        <div className="bg-indigo-50/70 dark:bg-indigo-950/40 px-6 py-3 border-b border-indigo-100 dark:border-indigo-900/50 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-indigo-900 dark:text-indigo-300">
            <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>High registration rush today?</span>
          </div>
          <button
            type="button"
            onClick={() => {
              onBatchSimulate(50);
              onClose();
            }}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs whitespace-nowrap shadow-xs transition-colors"
          >
            Batch Register 50 Students
          </button>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Student Photo Capture */}
          <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 shrink-0 flex items-center justify-center">
                {capturedPhoto ? (
                  <img src={capturedPhoto} alt="Captured student" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-5 h-5 text-slate-400" />
                )}
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Student ID Photo
                </span>
                <span className="text-[11px] text-slate-500">
                  {capturedPhoto ? 'Photo captured from camera' : 'Optional — capture live camera photo'}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsCameraOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{capturedPhoto ? 'Retake' : 'Open Camera'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Student Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Rahul Sharma"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Phone Number (for Reminders) *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="student@example.com"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Study Target / Exam
              </label>
              <select
                value={courseOrExam}
                onChange={e => setCourseOrExam(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Civil Services / UPSC">Civil Services / UPSC</option>
                <option value="Medical School / USMLE / NEET">Medical School / USMLE / NEET</option>
                <option value="Bar Exam / Legal Studies">Bar Exam / Legal Studies</option>
                <option value="Graduate Engineering / GATE">Graduate Engineering / GATE</option>
                <option value="CPA / Accounting">CPA / Accounting</option>
                <option value="Remote Software Work">Remote Software Work</option>
                <option value="College General Studies">College General Studies</option>
              </select>
            </div>
          </div>

          {/* Multi-shift selection */}
          <div className="space-y-2 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Shift Timing * (Multi-select)
              </label>
              <span className="text-[11px] font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                {selectedShifts.length} selected
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {SHIFT_LIST.map(shiftDef => {
                const isSelected = selectedShifts.includes(shiftDef.id);
                return (
                  <button
                    type="button"
                    key={shiftDef.id}
                    onClick={() => handleToggleShift(shiftDef.id)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border text-left flex items-center gap-1.5 transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <span className={`w-3 h-3 rounded flex items-center justify-center text-[9px] ${
                      isSelected ? 'bg-white text-indigo-700 font-bold' : 'border border-slate-300 dark:border-slate-600'
                    }`}>
                      {isSelected ? '✓' : ''}
                    </span>
                    <span>{shiftDef.shortLabel}</span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              Active ({getTotalShiftHours(selectedShifts)}h/day): {formatStudentShifts(selectedShifts)}
            </p>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Desk Allocation
            </label>
            <input
              type="text"
              value={assignedDesk}
              onChange={e => setAssignedDesk(e.target.value)}
              placeholder="e.g. A-15, B-22, or Flex"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
            <input
              type="checkbox"
              id="lockerCheckbox"
              checked={hasLocker}
              onChange={e => setHasLocker(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
            />
            <label htmlFor="lockerCheckbox" className="text-xs text-slate-700 dark:text-slate-300">
              Assign dedicated storage locker
            </label>
          </div>

          {/* Billing & Payment Toggle */}
          <div className="p-3.5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                  <IndianRupee className="w-3.5 h-3.5 text-indigo-600" />
                  Fee ({getTotalShiftHours(selectedShifts)}h):
                </span>
                <input
                  type="number"
                  min={0}
                  value={computedMonthlyFee}
                  onChange={e => setCustomFee(Number(e.target.value))}
                  className="w-24 px-2.5 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white"
                />
                {customFee !== null && customFee !== recommendedShiftFee && (
                  <button
                    type="button"
                    onClick={() => setCustomFee(null)}
                    className="text-[10px] text-indigo-600 font-semibold hover:underline"
                  >
                    Reset (₹{recommendedShiftFee})
                  </button>
                )}
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  checked={initialPaymentCollected}
                  onChange={e => setInitialPaymentCollected(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded"
                />
                Mark Fee Paid Now
              </label>
            </div>

            {initialPaymentCollected && (
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Method:</span>
                  {(['UPI', 'CASH', 'CARD'] as const).map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPaymentMethod(m)}
                      className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                        paymentMethod === m
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white dark:bg-slate-800 text-slate-600 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500">Paid on:</span>
                  <input
                    type="date"
                    value={paymentDate}
                    onChange={e => setPaymentDate(e.target.value)}
                    className="px-2 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 text-xs font-mono"
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-indigo-100/80 dark:border-indigo-900/40">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  ID Valid From
                </label>
                <input
                  type="date"
                  value={validFromDate}
                  onChange={e => setValidFromDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  ID Valid To
                </label>
                <input
                  type="date"
                  value={validToDate}
                  onChange={e => setValidToDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Additional Notes / Guardian / ID Details (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Father: Suresh Kumar · Aadhaar ending 4421"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm flex items-center gap-2 transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>Complete Registration & Issue ID</span>
            </button>
          </div>
        </form>
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        studentName={name}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => setCapturedPhoto(dataUrl)}
      />
    </div>
  );
};
