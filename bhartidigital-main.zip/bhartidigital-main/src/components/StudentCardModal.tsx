import React, { useState, useEffect } from 'react';
import { X, Printer, Share2, QrCode, Shield, Check, Pencil, Camera, CalendarRange, IndianRupee, Heart, Award } from 'lucide-react';
import { Student, LibrarySettings, formatStudentShifts } from '../types';
import { generateQrDataUrl } from '../utils/qr';
import { CameraCaptureModal } from './CameraCaptureModal';
import { resolveStudentAvatar } from '../utils/assets';

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatIdDate(iso?: string): string {
  if (!iso) return 'Pending';
  const clean = iso.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return iso;
  const [year, monthStr, day] = parts;
  const monthIdx = parseInt(monthStr, 10) - 1;
  return `${day} ${MONTHS_SHORT[monthIdx] || monthStr} ${year}`;
}

interface StudentCardModalProps {
  student: Student | null;
  settings: LibrarySettings;
  isAdmin?: boolean;
  onRequireAdmin?: () => void;
  onClose: () => void;
  onEdit?: (student: Student) => void;
  onUpdatePhoto?: (studentId: string, photoDataUrl: string) => void;
}

export const StudentCardModal: React.FC<StudentCardModalProps> = ({
  student,
  settings,
  isAdmin = true,
  onRequireAdmin,
  onClose,
  onEdit,
  onUpdatePhoto,
}) => {
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  useEffect(() => {
    if (student) {
      generateQrDataUrl(student.id, 240).then(url => setQrUrl(url));
    }
  }, [student]);

  if (!student) return null;

  const displayAvatarSrc = resolveStudentAvatar(student.avatarUrl);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`${window.location.origin}?student_id=${student.id}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenCamera = () => {
    if (!isAdmin) {
      onRequireAdmin?.();
      return;
    }
    setIsCameraOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl my-auto max-h-[94vh] flex flex-col">
        {/* Top Modal Header */}
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between no-print bg-gradient-to-r from-amber-50/70 via-rose-50/60 to-indigo-50/70 dark:from-slate-900 dark:via-indigo-950/40 dark:to-slate-900 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-amber-500 via-rose-500 to-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Shield className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Digital Library Pass</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full hover:bg-white/80 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Printable Colourful Pass Card */}
        <div className="p-4 sm:p-5 overflow-y-auto">
          <div className="rounded-2xl p-[2px] bg-gradient-to-br from-amber-400 via-rose-500 to-cyan-400 shadow-xl">
            <div className="rounded-[14px] bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 text-white p-4 sm:p-5 relative overflow-hidden">
              {/* Top Rainbow Honour Strip */}
              <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-rose-500 via-fuchsia-500 to-emerald-400"></div>

              {/* Ambient Colour Glows */}
              <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-rose-500/20 blur-2xl pointer-events-none"></div>
              <div className="absolute top-1/3 -left-12 w-36 h-36 rounded-full bg-amber-400/15 blur-2xl pointer-events-none"></div>
              <div className="absolute -bottom-10 -right-8 w-40 h-40 rounded-full bg-cyan-400/20 blur-2xl pointer-events-none"></div>

              {/* Library Branding Bar */}
              <div className="relative flex items-center justify-between border-b border-white/15 pb-3 mb-3.5 gap-2 pt-0.5">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                    <span className="text-[11px] font-extrabold uppercase tracking-wider bg-gradient-to-r from-amber-300 via-rose-200 to-cyan-300 bg-clip-text text-transparent block truncate">
                      {settings.name || 'Bharti Digital Library'}
                    </span>
                  </div>
                  <span className="text-[10px] text-amber-200/80 block mt-0.5">
                    Honoured Scholar · Privilege ID Pass
                  </span>
                </div>
                <div
                  className="px-2 py-0.5 rounded-md bg-gradient-to-r from-cyan-500/25 to-indigo-500/25 text-cyan-200 font-mono text-[9px] font-semibold border border-cyan-300/30 shrink-0 max-w-[145px] truncate"
                  title={formatStudentShifts(student.shifts, student.shift)}
                >
                  {formatStudentShifts(student.shifts, student.shift)}
                </div>
              </div>

              {/* Student Photo & Identity */}
              <div className="relative flex items-center gap-3.5 mb-3.5">
                <div className="p-[2px] rounded-xl bg-gradient-to-br from-amber-300 via-rose-400 to-cyan-400 shrink-0 shadow-md">
                  <div className="w-16 h-16 rounded-[10px] overflow-hidden bg-slate-900 relative group">
                    <img
                      src={displayAvatarSrc}
                      alt={student.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    {onUpdatePhoto && (
                      <button
                        type="button"
                        onClick={handleOpenCamera}
                        className="no-print absolute bottom-1 right-1 w-6 h-6 rounded-lg bg-gradient-to-r from-rose-500 to-indigo-600 hover:from-rose-400 hover:to-indigo-500 text-white flex items-center justify-center shadow-md border border-white/40 transition-transform hover:scale-105"
                        title={isAdmin ? 'Capture Student Photo with Camera' : 'Admin PIN required to update photo'}
                      >
                        <Camera className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
                <div className="overflow-hidden">
                  <h4 className="text-base font-extrabold text-white truncate leading-tight tracking-tight">
                    {student.name}
                  </h4>
                  <p className="text-[11px] text-amber-300 font-mono font-semibold mt-0.5">
                    ID: {student.id}
                  </p>
                  <p className="text-[10px] text-cyan-200/90 truncate mt-0.5">
                    {student.courseOrExam || 'Dedicated Study Scholar'}
                  </p>
                </div>
              </div>

              {/* Colourful Desk, PIN & Locker Highlights */}
              <div className="relative grid grid-cols-3 gap-2 mb-3.5">
                <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-400/30 text-center">
                  <span className="text-[9px] uppercase tracking-wider text-emerald-200 block">Desk Slot</span>
                  <span className="text-sm font-extrabold font-mono text-emerald-300">{student.assignedDesk}</span>
                </div>
                <div className="p-2 rounded-xl bg-amber-500/15 border border-amber-400/30 text-center">
                  <span className="text-[9px] uppercase tracking-wider text-amber-200 block">Kiosk PIN</span>
                  <span className="text-sm font-extrabold font-mono text-amber-300">{student.pin}</span>
                </div>
                <div className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-400/30 text-center">
                  <span className="text-[9px] uppercase tracking-wider text-cyan-200 block">Locker</span>
                  <span className="text-sm font-extrabold font-mono text-cyan-200">{student.lockerNumber || 'None'}</span>
                </div>
              </div>

              {/* Framed QR Code for Kiosk Entry */}
              <div className="relative rounded-xl p-[2px] bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-400 shadow-lg">
                <div className="bg-white rounded-[10px] p-2.5 flex flex-col items-center justify-center text-slate-900">
                  {qrUrl ? (
                    <img src={qrUrl} alt={`QR for ${student.id}`} className="w-24 h-24 sm:w-28 sm:h-28" />
                  ) : (
                    <div className="w-24 h-24 sm:w-28 sm:h-28 bg-slate-100 flex items-center justify-center">
                      <QrCode className="w-10 h-10 text-slate-400" />
                    </div>
                  )}
                  <span className="text-[9px] font-mono tracking-widest text-indigo-700 mt-1 uppercase font-bold">
                    SCAN AT ENTRY KIOSK
                  </span>
                </div>
              </div>

              {/* Admission, Payment Date & Card Validity From/To Section */}
              <div className="relative mt-3 rounded-xl bg-white/10 backdrop-blur-xs border border-white/15 p-2.5 space-y-2">
                <div className="flex items-center justify-between text-[11px] border-b border-white/15 pb-1.5 gap-1">
                  <span className="text-purple-200 flex items-center gap-1 font-medium shrink-0">
                    <span>Admission Date</span>
                  </span>
                  <strong className="text-white font-mono">
                    {formatIdDate(student.joinedDate)}
                  </strong>
                </div>

                <div className="flex items-center justify-between text-[11px] border-b border-white/15 pb-1.5 gap-1">
                  <span className="text-amber-200 flex items-center gap-1 font-medium shrink-0">
                    <IndianRupee className="w-3 h-3 text-emerald-300" />
                    <span>Payment Date</span>
                  </span>
                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    <strong className="text-white font-mono">
                      {student.lastPaymentDate ? formatIdDate(student.lastPaymentDate) : 'Not Paid'}
                    </strong>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide ${
                        student.paymentStatus === 'PAID'
                          ? 'bg-emerald-400/25 text-emerald-200 border border-emerald-300/40'
                          : student.paymentStatus === 'DUE_SOON'
                          ? 'bg-amber-400/25 text-amber-200 border border-amber-300/40'
                          : 'bg-rose-500/30 text-rose-200 border border-rose-300/40'
                      }`}
                    >
                      ₹{student.monthlyFee} · {student.paymentStatus.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] gap-1">
                  <span className="text-cyan-200 flex items-center gap-1 font-medium shrink-0">
                    <CalendarRange className="w-3 h-3 text-cyan-300" />
                    <span>Card Validity</span>
                  </span>
                  <div className="text-right font-mono">
                    <span className="text-slate-200">
                      From <strong className="text-amber-200">{formatIdDate(student.cardValidFrom || student.lastPaymentDate || student.joinedDate)}</strong>
                    </span>
                    <span className="text-rose-300 mx-1">→</span>
                    <span className="text-slate-200">
                      To{' '}
                      <strong
                        className={
                          student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED'
                            ? 'text-rose-300'
                            : 'text-emerald-300'
                        }
                      >
                        {formatIdDate(student.renewalDueDate)}
                      </strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Warm Gratitude & Appreciation Note */}
              <div className="relative mt-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-fuchsia-500/20 border border-amber-300/30 p-2.5 text-center">
                <div className="flex items-center justify-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-amber-200 mb-1">
                  <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
                  <span>With Heartfelt Gratitude</span>
                  <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
                </div>
                <p className="text-[10.5px] leading-relaxed text-amber-50/95">
                  Thank you, <strong className="text-white">{student.name.split(' ')[0]}</strong>, for trusting{' '}
                  <strong className="text-amber-200">{settings.name || 'Bharti Digital Library'}</strong>. Wishing you deep focus, wisdom, and grand success ahead!
                </p>
                <p className="text-[9px] text-rose-200/90 mt-1 font-medium">
                  Warm regards · {settings.ownerName && settings.ownerName !== 'Chandu Yadav' && settings.ownerName !== 'Mukesh Kumar' ? settings.ownerName : 'Raj'} & Library Family
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 no-print shrink-0">
          <button
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-xs transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
          {onUpdatePhoto && (
            <button
              type="button"
              onClick={handleOpenCamera}
              className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100 transition-colors"
              title="Capture Student Photo"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Photo</span>
            </button>
          )}
          {onEdit && (
            <button
              onClick={() => {
                onClose();
                onEdit(student);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>
          )}
          <button
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Copy Student Pass Link"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Share2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        studentName={student.name}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => {
          onUpdatePhoto?.(student.id, dataUrl);
        }}
      />
    </div>
  );
};
