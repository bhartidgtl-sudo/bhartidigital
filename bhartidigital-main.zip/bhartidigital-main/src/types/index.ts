export type ShiftType = 
  | 'FULL_DAY' 
  | 'DAY_9TO5' 
  | 'TWELVE_HOURS'
  | 'MORNING' 
  | 'AFTERNOON' 
  | 'EVENING' 
  | 'NIGHT_OWL' 
  | 'TWENTY_FOUR_HOURS';

export type PlanType = 
  | 'MONTHLY_FULL_DAY' 
  | 'MONTHLY_HALF_DAY' 
  | 'RESERVED_CUBICLE' 
  | 'QUARTERLY_PASS'
  | 'DAILY_PASS';

export type PaymentStatus = 'PAID' | 'DUE_SOON' | 'OVERDUE' | 'EXPIRED';

export type AttendanceStatus = 'CHECKED_IN' | 'CHECKED_OUT';

export interface Student {
  id: string; // e.g. "LIB-1042"
  pin: string; // 4 digits e.g. "2941"
  name: string;
  phone: string;
  email: string;
  avatarUrl: string;
  assignedDesk: string; // e.g. "A-12" or "General / Flex"
  hasLocker: boolean;
  lockerNumber?: string;
  shift: ShiftType;
  shifts?: ShiftType[]; // Multi-shift selection e.g. ['MORNING', 'EVENING']
  plan: PlanType;
  monthlyFee: number;
  paymentStatus: PaymentStatus;
  joinedDate: string; // ISO date
  cardValidFrom?: string; // ISO date for ID card validity start
  renewalDueDate: string; // ISO date for ID card validity end
  lastPaymentDate?: string; // ISO date of latest fee payment
  attendanceStatus: AttendanceStatus;
  currentCheckInTime?: string; // ISO timestamp if checked in
  currentCheckInDurationMinutes?: number;
  totalVisitsThisMonth: number;
  avgHoursPerVisit: number;
  courseOrExam?: string; // e.g. "UPSC / Civil Services", "Medical / NEET", "Engineering", "Remote Work"
  notes?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  assignedDesk: string;
  shift: ShiftType;
  checkInTime: string;
  checkOutTime?: string;
  durationMinutes?: number;
  method: 'QR_SCAN' | 'PIN_KIOSK' | 'STAFF_MANUAL' | 'BIOMETRIC_SIM';
  overtimeAlert?: boolean; // If student is studying past their allocated shift
}

export interface Invoice {
  id: string;
  studentId: string;
  studentName: string;
  phone: string;
  planName: string;
  amount: number;
  paidDate: string;
  periodStart: string;
  periodEnd: string;
  paymentMethod: 'UPI' | 'CASH' | 'CARD' | 'BANK_TRANSFER';
  transactionRef: string;
  status: 'PAID' | 'PENDING' | 'OVERDUE';
}

export interface PushReminder {
  id: string;
  studentId: string;
  studentName: string;
  phone: string;
  type: 'DUE_IN_3_DAYS' | 'DUE_TODAY' | 'OVERDUE_ALERT' | 'CHECKIN_ALERT';
  title: string;
  message: string;
  sentAt: string;
  channel: 'PUSH' | 'WHATSAPP' | 'SMS';
  status: 'DELIVERED' | 'QUEUED' | 'OPENED';
}

export interface PeakHourData {
  hour: number; // 6 to 23
  label: string; // "6 AM", "7 AM", etc.
  occupancyCount: number;
  capacityPercentage: number;
  isPeak: boolean;
}

export interface RetentionCohort {
  cohortMonth: string; // "June 2026", "July 2026", etc.
  totalRegistered: number;
  retainedMonth1: number; // %
  retainedMonth2: number;
  retainedMonth3: number;
  retainedMonth6: number;
  dropReasonTop: string;
}

export interface LibrarySettings {
  name: string;
  tagline: string;
  ownerName: string;
  phone: string;
  email: string;
  address: string;
  totalDesks: number;
  monthlyFees: {
    FULL_DAY: number;
    DAY_9TO5: number;
    TWELVE_HOURS: number;
    MORNING: number;
    AFTERNOON: number;
    EVENING: number;
    NIGHT_OWL: number;
    TWENTY_FOUR_HOURS: number;
    RESERVED_CUBICLE: number;
  };
  currency: string;
  upiNumber?: string;
  upiId?: string;
  upiPayeeName?: string;
  phonePeQrImageUrl?: string;
  notificationsEnabled: boolean;
  autoRemindDaysBefore: number;
}

export type ApplicationStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface StudentApplication {
  id: string; // e.g. "APP-2026-108"
  fullName: string;
  phone: string;
  email: string;
  courseOrExam: string;
  desiredShift: ShiftType;
  desiredShifts?: ShiftType[]; // Multi-shift selection support
  desiredPlan: PlanType;
  deskPreference?: string;
  hasLocker: boolean;
  govtIdType: string;
  govtIdNumber: string;
  avatarUrl?: string;
  submittedAt: string; // ISO
  status: ApplicationStatus;
  reviewedAt?: string;
  admissionDate?: string;
  rejectionReason?: string;
  assignedDesk?: string;
  studentIdCreated?: string;
}

export interface ShiftDefinition {
  id: ShiftType;
  label: string;
  timing: string;
  shortLabel: string;
  hours: number;
  defaultFee: number;
  tagColor: string;
  badgeColor: string;
}

export const SHIFT_LIST: ShiftDefinition[] = [
  {
    id: 'AFTERNOON',
    label: '4 Hours Afternoon (12 PM - 4 PM)',
    timing: '12:00 PM - 04:00 PM',
    shortLabel: '4 Hr (12PM-4PM)',
    hours: 4,
    defaultFee: 300,
    tagColor: 'bg-orange-50 text-orange-700 border-orange-200',
    badgeColor: 'bg-orange-500',
  },
  {
    id: 'MORNING',
    label: '6 Hours Morning (6 AM - 12 PM)',
    timing: '06:00 AM - 12:00 PM',
    shortLabel: '6 Hr Morning (6AM-12PM)',
    hours: 6,
    defaultFee: 400,
    tagColor: 'bg-amber-50 text-amber-700 border-amber-200',
    badgeColor: 'bg-amber-500',
  },
  {
    id: 'EVENING',
    label: '6 Hours Evening (5 PM - 11 PM)',
    timing: '05:00 PM - 11:00 PM',
    shortLabel: '6 Hr Evening (5PM-11PM)',
    hours: 6,
    defaultFee: 400,
    tagColor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    badgeColor: 'bg-indigo-500',
  },
  {
    id: 'DAY_9TO5',
    label: '8 Hours Day (9 AM - 5 PM)',
    timing: '09:00 AM - 05:00 PM',
    shortLabel: '8 Hr (9AM-5PM)',
    hours: 8,
    defaultFee: 500,
    tagColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    badgeColor: 'bg-emerald-500',
  },
  {
    id: 'NIGHT_OWL',
    label: '8 Hours Night (9 PM - 5 AM)',
    timing: '09:00 PM - 05:00 AM',
    shortLabel: '8 Hr Night (9PM-5AM)',
    hours: 8,
    defaultFee: 500,
    tagColor: 'bg-zinc-800 text-zinc-100 border-zinc-700',
    badgeColor: 'bg-zinc-600',
  },
  {
    id: 'TWELVE_HOURS',
    label: '12 Hours Shift (7 AM - 7 PM)',
    timing: '07:00 AM - 07:00 PM',
    shortLabel: '12 Hr (7AM-7PM)',
    hours: 12,
    defaultFee: 700,
    tagColor: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    badgeColor: 'bg-cyan-500',
  },
  {
    id: 'FULL_DAY',
    label: 'Full Day (6 AM - 11 PM)',
    timing: '06:00 AM - 11:00 PM',
    shortLabel: 'Full Day (6AM-11PM)',
    hours: 17,
    defaultFee: 750,
    tagColor: 'bg-blue-50 text-blue-700 border-blue-200',
    badgeColor: 'bg-blue-500',
  },
  {
    id: 'TWENTY_FOUR_HOURS',
    label: '24 Hours (9 AM - 9 AM)',
    timing: '09:00 AM - 09:00 AM',
    shortLabel: '24 Hr (9AM-9AM)',
    hours: 24,
    defaultFee: 800,
    tagColor: 'bg-purple-50 text-purple-700 border-purple-200',
    badgeColor: 'bg-purple-500',
  },
];

export function getShiftDefinition(shift: ShiftType): ShiftDefinition {
  return SHIFT_LIST.find(s => s.id === shift) || SHIFT_LIST[0];
}

export function formatStudentShifts(shifts?: ShiftType[], fallbackShift?: ShiftType): string {
  if (shifts && shifts.length > 0) {
    return shifts.map(s => getShiftDefinition(s).shortLabel).join(' + ');
  }
  if (fallbackShift) {
    return getShiftDefinition(fallbackShift).shortLabel;
  }
  return 'Flexible Shift';
}

export function getTotalShiftHours(shifts?: ShiftType[], fallbackShift?: ShiftType): number {
  const activeShifts = shifts && shifts.length > 0 ? shifts : [fallbackShift || ('DAY_9TO5' as ShiftType)];
  if (activeShifts.includes('TWENTY_FOUR_HOURS')) return 24;
  const total = activeShifts.reduce((acc, s) => acc + getShiftDefinition(s).hours, 0);
  return Math.min(24, total);
}

export function calculateShiftFee(
  shifts: ShiftType[],
  monthlyFees?: LibrarySettings['monthlyFees'],
  _plan?: PlanType,
  _hasLocker?: boolean
): number {
  const activeShifts = shifts.length > 0 ? shifts : ['DAY_9TO5' as ShiftType];
  if (activeShifts.includes('TWENTY_FOUR_HOURS')) {
    return monthlyFees?.TWENTY_FOUR_HOURS ?? 800;
  }

  // If a single shift is selected, use configured monthlyFees override if available
  if (activeShifts.length === 1) {
    const single = activeShifts[0];
    return monthlyFees?.[single] ?? getShiftDefinition(single).defaultFee;
  }

  // Multiple shifts selected: calculate total hours and map to exact shift-duration brackets
  const totalHours = getTotalShiftHours(activeShifts);
  if (totalHours <= 4) return monthlyFees?.AFTERNOON ?? 300;
  if (totalHours <= 6) return monthlyFees?.MORNING ?? 400;
  if (totalHours <= 8) return monthlyFees?.DAY_9TO5 ?? 500;
  if (totalHours <= 10) return 600;
  if (totalHours <= 12) return monthlyFees?.TWELVE_HOURS ?? 700;
  if (totalHours <= 18) return monthlyFees?.FULL_DAY ?? 750;
  return monthlyFees?.TWENTY_FOUR_HOURS ?? 800;
}

