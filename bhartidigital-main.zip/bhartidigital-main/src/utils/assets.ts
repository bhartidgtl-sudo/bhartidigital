import defaultStudentAvatar from '../assets/images/student_id_avatar_1794499631389.jpg';
import libraryHeroImage from '../assets/images/library_interior_study_1794499630586.jpg';

export { defaultStudentAvatar, libraryHeroImage };

export function resolveStudentAvatar(avatarUrl?: string): string {
  if (!avatarUrl) return defaultStudentAvatar;
  if (avatarUrl.startsWith('data:image/')) return avatarUrl;
  if (avatarUrl.includes('student_id_avatar')) return defaultStudentAvatar;
  return defaultStudentAvatar;
}

export function hasCustomOrDefaultPhoto(avatarUrl?: string): boolean {
  if (!avatarUrl) return false;
  return avatarUrl.startsWith('data:image/') || avatarUrl.includes('student_id_avatar');
}
