import React from 'react';
import { LayoutDashboard, Users, Clock, CreditCard, BarChart3, QrCode } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenKiosk: () => void;
  checkedInCount: number;
  overdueCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenKiosk,
  checkedInCount,
  overdueCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 md:hidden pb-safe">
      <div className="grid grid-cols-5 h-16 items-center px-1">
        {/* Hub / Dashboard */}
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            activeTab === 'dashboard'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">Hub</span>
        </button>

        {/* Live Attendance */}
        <button
          onClick={() => setActiveTab('attendance')}
          className={`relative flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            activeTab === 'attendance'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">Live ({checkedInCount})</span>
          {checkedInCount > 0 && (
            <span className="absolute top-2 right-4 w-2 h-2 rounded-full bg-emerald-500"></span>
          )}
        </button>

        {/* Fast Kiosk Scan Action (Hero Center Button) */}
        <button
          onClick={onOpenKiosk}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-slate-800 dark:text-slate-100 group"
          title="Instant Kiosk Scanner"
        >
          <div className="w-10 h-10 rounded-full bg-indigo-600 dark:bg-indigo-500 text-white flex items-center justify-center shadow-md shadow-indigo-600/20 group-active:scale-95 transition-transform">
            <QrCode className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-medium tracking-tight mt-0.5 whitespace-nowrap">Kiosk</span>
        </button>

        {/* Members */}
        <button
          onClick={() => setActiveTab('members')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            activeTab === 'members'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">Students</span>
        </button>

        {/* Billing / Analytics */}
        <button
          onClick={() => setActiveTab('billing')}
          className={`relative flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            activeTab === 'billing' || activeTab === 'analytics'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <CreditCard className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">Billing</span>
          {overdueCount > 0 && (
            <span className="absolute top-2 right-4 w-2 h-2 rounded-full bg-rose-500"></span>
          )}
        </button>
      </div>
    </nav>
  );
};
