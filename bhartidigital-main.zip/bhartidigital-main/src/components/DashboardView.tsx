import React from 'react';
import { 
  Users, 
  Clock, 
  IndianRupee, 
  AlertCircle, 
  QrCode, 
  UserPlus, 
  TrendingUp, 
  Send, 
  Sparkles,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  CheckCircle2,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { Student, PeakHourData, LibrarySettings, StudentApplication } from '../types';
import { libraryHeroImage } from '../utils/assets';

interface DashboardViewProps {
  students: Student[];
  peakHours: PeakHourData[];
  settings: LibrarySettings;
  pendingApplications: StudentApplication[];
  onOpenKiosk: () => void;
  onOpenRegister: () => void;
  onOpenSelfRegister: () => void;
  onOpenApprovals: () => void;
  onOpenNotifications: () => void;
  onSelectStudent: (student: Student) => void;
  setActiveTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  students,
  peakHours,
  settings,
  pendingApplications,
  onOpenKiosk,
  onOpenRegister,
  onOpenSelfRegister,
  onOpenApprovals,
  onOpenNotifications,
  onSelectStudent,
  setActiveTab,
}) => {
  const activeStudents = students.filter(s => s.attendanceStatus === 'CHECKED_IN');
  const overdueStudents = students.filter(s => s.paymentStatus === 'OVERDUE');
  const dueSoonStudents = students.filter(s => s.paymentStatus === 'DUE_SOON');
  const pendingCount = pendingApplications.filter(a => a.status === 'PENDING').length;

  const occupancyRate = Math.round((activeStudents.length / settings.totalDesks) * 100);

  // Financial calculations
  const totalCollectedMonth = students
    .filter(s => s.paymentStatus === 'PAID')
    .reduce((acc, s) => acc + s.monthlyFee, 0);

  const totalPendingDues = [...overdueStudents, ...dueSoonStudents]
    .reduce((acc, s) => acc + s.monthlyFee, 0);

  // Find peak hour today
  const highestPeak = peakHours.reduce((prev, current) => 
    (prev.occupancyCount > current.occupancyCount) ? prev : current
  );

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Welcome & Library Hero Card */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-xl">
        <img
          src={libraryHeroImage}
          alt="Library Study Hall"
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative z-10 p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
                <span>Director Overview</span>
                <span>·</span>
                <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white text-balance">
                {settings.name}
              </h1>
              <p className="text-sm text-slate-300 max-w-xl mt-1">
                Currently accommodating <strong className="text-emerald-400 font-mono">{activeStudents.length}</strong> active learners across {settings.totalDesks} dedicated study cubicles.
              </p>
            </div>

            {/* Quick Action Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveTab('student-portal')}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-500/90 hover:bg-emerald-500 text-white font-bold text-xs backdrop-blur-md transition-all whitespace-nowrap min-h-[44px]"
                title="Student Login, Profile & Online Fee Payment"
              >
                <IndianRupee className="w-4 h-4" />
                <span>Student Login & Pay</span>
              </button>

              <button
                onClick={onOpenSelfRegister}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs backdrop-blur-md transition-all whitespace-nowrap min-h-[44px]"
                title="Student Self-Registration Portal"
              >
                <UserPlus className="w-4 h-4 text-indigo-300" />
                <span>Self Register</span>
              </button>

              <button
                onClick={onOpenApprovals}
                className="relative flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Approvals</span>
                {pendingCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                    {pendingCount}
                  </span>
                )}
              </button>

              <button
                onClick={onOpenKiosk}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <QrCode className="w-4 h-4 text-indigo-600" />
                <span>Kiosk Mode</span>
              </button>

              <button
                onClick={onOpenRegister}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <span>+ Direct Add</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Pending Student Registrations Queue Card (When applicants exist) */}
      {pendingCount > 0 && (
        <div className="p-5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold">
                <UserCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-amber-950 dark:text-amber-200">
                  {pendingCount} Students Self-Registered — Awaiting Admin Approval
                </h3>
                <p className="text-xs text-amber-800/80 dark:text-amber-300/80">
                  Verify identity proofs, assign designated desk numbers, and issue digital entry passes.
                </p>
              </div>
            </div>
            <button
              onClick={onOpenApprovals}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto shadow-sm"
            >
              <span>Review All ({pendingCount})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
            {pendingApplications.filter(a => a.status === 'PENDING').slice(0, 4).map(app => (
              <div
                key={app.id}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-amber-200/60 dark:border-amber-900/40 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white truncate">{app.fullName}</span>
                  <span className="text-[10px] font-mono text-indigo-600 font-semibold">{app.desiredShift.replace('_', ' ')}</span>
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  Goal: {app.courseOrExam}
                </div>
                <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span>Pref: {app.deskPreference || 'Any'}</span>
                  <button
                    onClick={onOpenApprovals}
                    className="text-amber-600 dark:text-amber-400 font-bold hover:underline"
                  >
                    Approve →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Occupancy Card */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Live Occupancy</span>
            <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-white">
              {activeStudents.length}
            </span>
            <span className="text-xs text-slate-500 font-mono">
              / {settings.totalDesks} seats
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden mr-2">
              <div 
                className={`h-full rounded-full ${occupancyRate > 90 ? 'bg-rose-500' : occupancyRate > 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style={{ width: `${Math.min(100, occupancyRate)}%` }}
              ></div>
            </div>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300 shrink-0">
              {occupancyRate}%
            </span>
          </div>
        </div>

        {/* Total Registered Members */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Total Members</span>
            <Sparkles className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-white">
              {students.length}
            </span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
              +108 Active
            </span>
          </div>
          <div className="mt-3 text-xs text-slate-500 truncate">
            Shift Capacity: Morning 94% · Evening 98%
          </div>
        </div>

        {/* Month Revenue Collections */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Monthly Collected</span>
            <IndianRupee className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-white">
              ₹{totalCollectedMonth.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="mt-3 text-xs text-slate-500 truncate">
            Automatic receipts & invoices issued
          </div>
        </div>

        {/* Pending & Overdue Fees */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Pending Dues</span>
            <AlertCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-rose-600 dark:text-rose-400">
              ₹{totalPendingDues.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-rose-600 font-semibold">
              ({overdueStudents.length} Overdue)
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <button
              onClick={onOpenNotifications}
              className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1"
            >
              <span>Send Reminders</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Daily Peak Rush Indicator & Mini Hourly Curve */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Daily Peak Hours & Real-Time Density
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Identifies congestion hours to optimize multi-shift desk allocations. Peak expected at <strong className="text-slate-800 dark:text-slate-200">{highestPeak.label} ({highestPeak.occupancyCount} seats)</strong>.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('analytics')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Full Analytics Report</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Hourly Histogram Bar Preview */}
        <div className="grid grid-cols-9 sm:grid-cols-18 gap-1 items-end h-28 pt-4 pb-2 border-b border-slate-100 dark:border-slate-800">
          {peakHours.map((hourData) => {
            const heightPercent = Math.round((hourData.occupancyCount / settings.totalDesks) * 100);
            const isHigh = hourData.occupancyCount >= 100;

            return (
              <div key={hourData.hour} className="flex flex-col items-center h-full justify-end group relative">
                {/* Tooltip on hover */}
                <div className="absolute -top-8 bg-slate-900 text-white text-[10px] py-1 px-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20 font-mono">
                  {hourData.label}: {hourData.occupancyCount} seats ({hourData.capacityPercentage}%)
                </div>
                <div
                  className={`w-full rounded-t transition-all ${
                    isHigh
                      ? 'bg-rose-500 group-hover:bg-rose-600'
                      : hourData.isPeak
                      ? 'bg-indigo-500 group-hover:bg-indigo-600'
                      : 'bg-slate-200 dark:bg-slate-700 group-hover:bg-slate-300'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                ></div>
                <span className="text-[9px] text-slate-400 font-mono mt-1 scale-90">
                  {hourData.hour}h
                </span>
              </div>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500"></span>
              <span>Heavy Rush (&gt;85%)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500"></span>
              <span>Optimal Occupancy</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-slate-200 dark:bg-slate-700"></span>
              <span>Light Hours</span>
            </span>
          </div>
          <span className="font-mono text-[11px]">Next expected lull: 1:00 PM - 3:00 PM</span>
        </div>
      </div>

      {/* Two Column Split: Currently Studying (Live) vs Urgent Payment Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Live Attendance Inside Right Now */}
        <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>Currently Inside Hall ({activeStudents.length})</span>
              </h3>
              <p className="text-xs text-slate-500">Real-time occupancy roster</p>
            </div>
            <button
              onClick={() => setActiveTab('attendance')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              View Roster
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {activeStudents.slice(0, 5).map(student => (
              <div
                key={student.id}
                onClick={() => onSelectStudent(student)}
                className="py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 px-2 rounded-xl transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs shrink-0">
                    {student.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {student.name}
                    </h4>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Desk {student.assignedDesk} · Shift: {student.shift.replace('_', ' ')}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400 block">
                    In since {student.currentCheckInTime ? student.currentCheckInTime.split('T')[1].substring(0, 5) : '08:00'}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ~{student.currentCheckInDurationMinutes || 120} mins spent
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Urgent Monthly Payment Reminders */}
        <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>Overdue & Expiring Memberships ({overdueStudents.length + dueSoonStudents.length})</span>
              </h3>
              <p className="text-xs text-slate-500">Automated reminder triggers</p>
            </div>
            <button
              onClick={onOpenNotifications}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              Push Center
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {[...overdueStudents, ...dueSoonStudents].slice(0, 5).map(student => (
              <div
                key={student.id}
                className="py-3 flex items-center justify-between gap-3 px-2 rounded-xl"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {student.name}
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                      student.paymentStatus === 'OVERDUE'
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                        : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                    }`}>
                      {student.paymentStatus === 'OVERDUE' ? 'Overdue' : 'Due in 3d'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Due: {student.renewalDueDate} · Desk {student.assignedDesk} · ₹{student.monthlyFee}
                  </div>
                </div>

                <button
                  onClick={() => onSelectStudent(student)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 shrink-0"
                >
                  Manage
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={() => setActiveTab('billing')}
            className="w-full py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>Manage All Library Dues & Receipts</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
