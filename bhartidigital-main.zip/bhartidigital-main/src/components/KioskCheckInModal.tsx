import React, { useState, useEffect } from 'react';
import { X, QrCode, Hash, CheckCircle2, LogOut, AlertTriangle, Sparkles, Camera, ArrowRight, UserCheck } from 'lucide-react';
import { Student } from '../types';
import { sounds } from '../utils/notifications';
import confetti from 'canvas-confetti';

interface KioskCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  onCheckInToggle: (studentId: string, method: 'QR_SCAN' | 'PIN_KIOSK') => { success: boolean; student?: Student; action?: 'IN' | 'OUT'; message?: string };
}

export const KioskCheckInModal: React.FC<KioskCheckInModalProps> = ({
  isOpen,
  onClose,
  students,
  onCheckInToggle,
}) => {
  const [mode, setMode] = useState<'QR' | 'PIN'>('PIN');
  const [pinInput, setPinInput] = useState('');
  const [feedback, setFeedback] = useState<{
    show: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    error?: string;
  }>({ show: false });
  const [cameraActive, setCameraActive] = useState(false);
  const [simulatedScanTarget, setSimulatedScanTarget] = useState<string>('');

  useEffect(() => {
    if (!isOpen) {
      setPinInput('');
      setFeedback({ show: false });
      setCameraActive(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleKeypadPress = (digit: string) => {
    if (pinInput.length < 6) {
      const nextPin = pinInput + digit;
      setPinInput(nextPin);
      if (nextPin.length === 4) {
        processPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPinInput(prev => prev.slice(0, -1));
  };

  const processPin = (pin: string) => {
    // Find student by PIN or by ID number
    const target = students.find(s => s.pin === pin || s.id.toLowerCase() === pin.toLowerCase() || s.id.endsWith(pin));
    if (!target) {
      sounds.playAlert();
      setFeedback({
        show: true,
        error: `No member found with PIN "${pin}". Please verify or ask staff.`,
      });
      setTimeout(() => {
        setPinInput('');
      }, 1500);
      return;
    }

    const res = onCheckInToggle(target.id, 'PIN_KIOSK');
    if (res.action === 'IN') {
      sounds.playSuccess();
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    } else {
      sounds.playCheckOut();
    }

    setFeedback({
      show: true,
      student: target,
      action: res.action,
    });

    setTimeout(() => {
      setPinInput('');
      setFeedback({ show: false });
    }, 2800);
  };

  const simulateQrScan = (studentId: string) => {
    const target = students.find(s => s.id === studentId);
    if (!target) return;

    const res = onCheckInToggle(studentId, 'QR_SCAN');
    if (res.action === 'IN') {
      sounds.playSuccess();
      try {
        confetti({
          particleCount: 45,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    } else {
      sounds.playCheckOut();
    }

    setFeedback({
      show: true,
      student: target,
      action: res.action,
    });

    setTimeout(() => {
      setFeedback({ show: false });
    }, 2800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl transition-all">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Self Check-In Kiosk</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Bharti Digital Library</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success or Error Overlay feedback */}
        {feedback.show ? (
          <div className="p-8 text-center space-y-4">
            {feedback.error ? (
              <div className="space-y-3">
                <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Check-in Error</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300">{feedback.error}</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                  feedback.action === 'IN' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'
                }`}>
                  {feedback.action === 'IN' ? <CheckCircle2 className="w-9 h-9" /> : <LogOut className="w-9 h-9" />}
                </div>
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    {feedback.action === 'IN' ? 'Checked In Successfully' : 'Checked Out Successfully'}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                    {feedback.student?.name}
                  </h3>
                  <div className="flex items-center justify-center gap-2 mt-2 text-xs text-slate-500 dark:text-slate-400 font-mono">
                    <span>ID: {feedback.student?.id}</span>
                    <span>·</span>
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400">Desk: {feedback.student?.assignedDesk}</span>
                    <span>·</span>
                    <span>Shift: {feedback.student?.shift.replace('_', ' ')}</span>
                  </div>
                </div>

                {feedback.student?.paymentStatus === 'OVERDUE' && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl text-left text-xs text-amber-800 dark:text-amber-300">
                    <strong>Payment Reminder:</strong> Your monthly fee was due on {feedback.student?.renewalDueDate}. Please visit the front desk to avoid desk cancellation.
                  </div>
                )}
                
                <p className="text-xs text-slate-400 pt-2">Screen resets in 2 seconds...</p>
              </div>
            )}
          </div>
        ) : (
          <div className="p-6 space-y-5">
            {/* Mode Switcher */}
            <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setMode('PIN')}
                className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  mode === 'PIN'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Hash className="w-3.5 h-3.5" />
                <span>Enter PIN / ID</span>
              </button>
              <button
                onClick={() => setMode('QR')}
                className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  mode === 'QR'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Camera className="w-3.5 h-3.5" />
                <span>QR Scanner</span>
              </button>
            </div>

            {mode === 'PIN' ? (
              <div className="space-y-4">
                {/* PIN Display */}
                <div className="text-center py-2">
                  <span className="text-xs text-slate-500 block mb-1">Enter your 4-digit PIN or Student Number</span>
                  <div className="h-12 flex items-center justify-center gap-2">
                    {[0, 1, 2, 3].map(i => (
                      <div
                        key={i}
                        className={`w-11 h-12 rounded-xl border flex items-center justify-center text-xl font-bold font-mono transition-all ${
                          pinInput[i]
                            ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-400 shadow-sm'
                            : 'border-slate-200 dark:border-slate-700 text-slate-300'
                        }`}
                      >
                        {pinInput[i] || '·'}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Touch Keypad */}
                <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
                    <button
                      key={num}
                      onClick={() => handleKeypadPress(num)}
                      className="h-12 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-center active:scale-95 transition-all shadow-xs"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    onClick={() => setPinInput('')}
                    className="h-12 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center justify-center active:scale-95"
                  >
                    Clear
                  </button>
                  <button
                    onClick={() => handleKeypadPress('0')}
                    className="h-12 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-center active:scale-95 transition-all shadow-xs"
                  >
                    0
                  </button>
                  <button
                    onClick={handleBackspace}
                    className="h-12 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center active:scale-95"
                  >
                    ⌫ Delete
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4 text-center">
                {/* QR Scanner viewport box */}
                <div className="relative w-56 h-56 mx-auto rounded-2xl bg-slate-900 border-2 border-indigo-500 flex flex-col items-center justify-center overflow-hidden shadow-inner">
                  <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/20 via-transparent to-indigo-500/20 animate-pulse pointer-events-none"></div>
                  
                  {/* Laser scanning line */}
                  <div className="absolute left-4 right-4 h-0.5 bg-red-500 shadow-[0_0_8px_#ef4444] animate-bounce top-1/2 -translate-y-1/2"></div>
                  
                  <QrCode className="w-20 h-20 text-slate-500/40" />
                  <p className="text-[11px] text-slate-300 font-medium mt-3 px-4 z-10">
                    Hold Student Digital ID or Badge in front of camera
                  </p>
                </div>

                <div className="text-xs text-slate-500">
                  <span>Or test with a sample student pass:</span>
                  <div className="flex flex-wrap justify-center gap-1.5 mt-2">
                    {students.slice(0, 3).map(s => (
                      <button
                        key={s.id}
                        onClick={() => simulateQrScan(s.id)}
                        className="px-2.5 py-1 text-[11px] bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-700 dark:text-slate-300 rounded-md font-mono transition-colors"
                      >
                        Scan {s.name.split(' ')[0]} ({s.assignedDesk})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 text-center flex items-center justify-between">
          <span>Auto-calculates entry/exit & overtime hours</span>
          <span className="font-mono text-emerald-600 dark:text-emerald-400">● Sensor Active</span>
        </div>
      </div>
    </div>
  );
};
