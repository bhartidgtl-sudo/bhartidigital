import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  UserCheck, 
  ShieldCheck, 
  Phone, 
  Mail, 
  Armchair, 
  MessageSquare, 
  FileText,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { StudentApplication, Student, LibrarySettings, ShiftType, SHIFT_LIST, formatStudentShifts, calculateShiftFee, getTotalShiftHours } from '../types';
import { sounds, sendBrowserPushNotification, generateWhatsAppReminderUrl } from '../utils/notifications';
import confetti from 'canvas-confetti';

interface AdminApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  applications: StudentApplication[];
  onApprove: (
    applicationId: string,
    assignedDesk: string,
    feePaidNow: boolean,
    approvedShifts?: ShiftType[],
    admissionDate?: string
  ) => { student: Student; application: StudentApplication };
  onReject: (applicationId: string, reason: string) => void;
  settings: LibrarySettings;
  availableDesksCount: number;
}

export const AdminApprovalModal: React.FC<AdminApprovalModalProps> = ({
  isOpen,
  onClose,
  applications,
  onApprove,
  onReject,
  settings,
  availableDesksCount,
}) => {
  const [filterStatus, setFilterStatus] = useState<'PENDING' | 'APPROVED' | 'REJECTED' | 'ALL'>('PENDING');
  const [selectedAppForApprove, setSelectedAppForApprove] = useState<StudentApplication | null>(null);
  const [assignDeskInput, setAssignDeskInput] = useState('A-19');
  const [admissionDate, setAdmissionDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [approvedShifts, setApprovedShifts] = useState<ShiftType[]>([]);
  const [feePaidNow, setFeePaidNow] = useState(true);
  const [rejectAppId, setRejectAppId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('Desired shift currently at full capacity');

  if (!isOpen) return null;

  const pendingApps = applications.filter(a => a.status === 'PENDING');
  const filteredApps = applications.filter(a => filterStatus === 'ALL' || a.status === filterStatus);

  const handleStartApprove = (app: StudentApplication) => {
    setSelectedAppForApprove(app);
    setAdmissionDate(new Date().toISOString().split('T')[0]);
    const initialShifts = app.desiredShifts && app.desiredShifts.length > 0 ? app.desiredShifts : [app.desiredShift];
    setApprovedShifts(initialShifts);

    // suggest a desk based on preference or next index
    const zone = app.deskPreference?.includes('Zone A') ? 'A' : app.deskPreference?.includes('Window') ? 'B' : 'C';
    const randNum = Math.floor(10 + Math.random() * 30);
    setAssignDeskInput(`${zone}-${randNum}`);
  };

  const handleToggleShift = (shiftId: ShiftType) => {
    if (approvedShifts.includes(shiftId)) {
      if (approvedShifts.length > 1) {
        setApprovedShifts(approvedShifts.filter(s => s !== shiftId));
      }
    } else {
      if (shiftId === 'TWENTY_FOUR_HOURS') {
        setApprovedShifts(['TWENTY_FOUR_HOURS']);
      } else {
        const without24 = approvedShifts.filter(s => s !== 'TWENTY_FOUR_HOURS');
        setApprovedShifts([...without24, shiftId]);
      }
    }
  };

  const handleConfirmApproval = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppForApprove) return;

    const res = onApprove(selectedAppForApprove.id, assignDeskInput, feePaidNow, approvedShifts, admissionDate);
    sounds.playSuccess();
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    sendBrowserPushNotification(
      '🎉 Membership Approved',
      `Approved ${res.student.name} for Desk ${res.student.assignedDesk} (${formatStudentShifts(res.student.shifts, res.student.shift)}).`
    );

    setSelectedAppForApprove(null);
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectAppId) return;
    onReject(rejectAppId, rejectReason);
    sounds.playAlert();
    setRejectAppId(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl my-6 transition-all">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Student Registration Approvals</h2>
                {pendingApps.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-bold font-mono">
                    {pendingApps.length} Pending
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">Verify student ID proofs and allocate study slots</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="px-6 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterStatus('PENDING')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                filterStatus === 'PENDING'
                  ? 'bg-amber-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Pending Review ({pendingApps.length})
            </button>
            <button
              onClick={() => setFilterStatus('APPROVED')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                filterStatus === 'APPROVED'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              Approved ({applications.filter(a => a.status === 'APPROVED').length})
            </button>
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                filterStatus === 'ALL'
                  ? 'bg-slate-900 text-white dark:bg-indigo-600'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              All Records ({applications.length})
            </button>
          </div>

          <span className="text-slate-500 font-mono hidden sm:inline">
            {availableDesksCount} seats available
          </span>
        </div>

        {/* Applications List */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-3">
          {filteredApps.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-xs">
              No registration applications in "{filterStatus.toLowerCase()}" queue.
            </div>
          ) : (
            filteredApps.map(app => {
              const waUrl = `https://wa.me/${app.phone.replace(/\D/g, '')}?text=${encodeURIComponent(
                `Hello ${app.fullName}, regarding your registration at ${settings.name}...`
              )}`;

              return (
                <div
                  key={app.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 shadow-xs space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200 flex items-center justify-center font-bold text-sm">
                        {app.fullName.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                            {app.fullName}
                          </h4>
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                            app.status === 'PENDING'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : app.status === 'APPROVED'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800'
                          }`}>
                            {app.status}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 font-mono mt-0.5 flex flex-wrap items-center gap-x-2">
                          <span>{app.id} · Applied: {app.submittedAt.split('T')[0]}</span>
                          {app.status === 'APPROVED' && (
                            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                              · Admission Date: {app.admissionDate || app.reviewedAt?.split('T')[0] || app.submittedAt.split('T')[0]}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Actions if pending */}
                    {app.status === 'PENDING' && (
                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <button
                          onClick={() => setRejectAppId(app.id)}
                          className="px-3 py-1.5 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-semibold"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => handleStartApprove(app)}
                          className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve & Assign Desk</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700/60 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Exam / Goal</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate block">{app.courseOrExam}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Shift(s) Requested</span>
                      <strong className="text-indigo-600 dark:text-indigo-400 block truncate" title={formatStudentShifts(app.desiredShifts, app.desiredShift)}>
                        {formatStudentShifts(app.desiredShifts, app.desiredShift)}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Desk Preference</span>
                      <strong className="text-slate-800 dark:text-slate-200 truncate block">{app.deskPreference || 'Any'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase font-mono">Locker</span>
                      <strong className="text-slate-800 dark:text-slate-200 block">{app.hasLocker ? 'Yes Required' : 'No'}</strong>
                    </div>
                  </div>

                  {/* ID Proof Verification Strip */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 pt-1">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 font-mono text-slate-700 dark:text-slate-300">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{app.govtIdType}: <strong>{app.govtIdNumber}</strong></span>
                      </span>
                      <span>·</span>
                      <span className="font-mono">{app.phone}</span>
                    </div>

                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-600 hover:underline flex items-center gap-1"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>Chat on WhatsApp</span>
                    </a>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Sub-Dialog: Desk Allocation & Final Approval */}
        {selectedAppForApprove && (
          <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Confirm Admission: {selectedAppForApprove.fullName}
                </h3>
                <button onClick={() => setSelectedAppForApprove(null)} className="text-slate-400">✕</button>
              </div>

              <form onSubmit={handleConfirmApproval} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Allocate Study Desk *
                    </label>
                    <input
                      type="text"
                      required
                      value={assignDeskInput}
                      onChange={e => setAssignDeskInput(e.target.value)}
                      placeholder="e.g. A-19 or Flex"
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-mono font-bold"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      Preferred: {selectedAppForApprove.deskPreference}
                    </span>
                  </div>

                  <div>
                    <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Admission Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={admissionDate}
                      onChange={e => setAdmissionDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-mono font-bold"
                    />
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 block">
                      Sets ID Pass start & admission record
                    </span>
                  </div>
                </div>

                {/* Shift Allocation */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">
                      Approved Shift(s) *
                    </label>
                    <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-mono">
                      {approvedShifts.length} selected
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {SHIFT_LIST.map(s => {
                      const isSel = approvedShifts.includes(s.id);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => handleToggleShift(s.id)}
                          className={`px-2 py-1 rounded-lg text-[11px] font-medium border transition-colors ${
                            isSel
                              ? 'bg-indigo-600 text-white border-indigo-600 font-semibold'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {isSel ? '✓ ' : ''}{s.shortLabel}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      Fee ({getTotalShiftHours(approvedShifts)}h): ₹{calculateShiftFee(approvedShifts, settings.monthlyFees)}/mo
                    </span>
                    <label className="flex items-center gap-1.5 cursor-pointer font-medium">
                      <input
                        type="checkbox"
                        checked={feePaidNow}
                        onChange={e => setFeePaidNow(e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded"
                      />
                      <span>Mark First Fee Paid</span>
                    </label>
                  </div>
                  <p className="text-[11px] text-indigo-900 dark:text-indigo-300">
                    Auto-generates student admission pass with QR Code, kiosk PIN, and official receipt.
                  </p>
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAppForApprove(null)}
                    className="px-4 py-2 font-semibold text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve & Send Digital ID</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal Sub-Dialog: Rejection */}
        {rejectAppId && (
          <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Reject Application</h3>
              <form onSubmit={handleConfirmReject} className="space-y-3 text-xs">
                <div>
                  <label className="text-slate-700 dark:text-slate-300 font-semibold block mb-1">
                    Reason for Rejection:
                  </label>
                  <select
                    value={rejectReason}
                    onChange={e => setRejectReason(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs"
                  >
                    <option value="Desired shift currently at full capacity">Desired shift currently at full capacity</option>
                    <option value="Incomplete or unverified ID proof">Incomplete or unverified ID proof</option>
                    <option value="Non-adherence to silent library rules">Non-adherence to silent library rules</option>
                    <option value="Duplicate registration submission">Duplicate registration submission</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setRejectAppId(null)}
                    className="px-4 py-2 font-semibold text-slate-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold"
                  >
                    Confirm Reject
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
